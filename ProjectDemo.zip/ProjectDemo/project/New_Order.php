<?php
	$cn =new mysqli("localhost","root","","sutex");
    $Order_date = date("Y-m-d H:i:s");
    $Payment_method = $_POST["Payment_method"];
    $Process_states = $_POST["Process_states"];
	$Total_amount = $_POST["Total_amount"];
	$Cust_address = $_POST["Cust_address"];
    $Cust_latitude = $_POST["Cust_latitude"];
    $Cust_longitude = $_POST["Cust_longitude"];
    $Offer_id = $_POST["Offer_id"];
    $Res_id = $_POST["Res_id"];
    $DE_id = $_POST["DE_id"];
    $Cust_id = $_POST["Cust_id"];
    $Item_id = $_POST["Item_id"];
    $Quantity = $_POST["Quantity"];
    
	$query = "insert into Order_Details(Order_date,Payment_method,Process_states,Total_amount,Cust_address,Cust_latitude,Cust_longitude,Offer_id,Res_id,DE_id,Cust_id,Item_id,Quantity)values('$Cust_name','$Cust_phno','$Cust_email','$Cust_password','$Cust_city')";
	$cn->query($query);
    echo "Successful"
?>
