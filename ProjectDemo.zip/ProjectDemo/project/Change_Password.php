<?php
	$cn =new mysqli("localhost","root","","sutex");
	$Cust_id = $_POST["Cust_id"];
	$Cust_password = $_POST["Cust_password"];

	$query = "update Customer_Details set Cust_password = '$Cust_password' where Cust_id = '$Cust_id'";
	$cn->query($query);
	
    $q = mysqli_query($cn,"select * from Customer_Details where Cust_id = '$Cust_id'");
    if(mysqli_num_rows($q) == 0)
    {
        $row = array();
        print_r(json_encode($row));
    }
    else
    {
        while($row = mysqli_fetch_assoc($q))
        {
            $p[] = $row;
        }
        echo json_encode($p);
    }
?>
