<?php
	$cn =new mysqli("localhost","root","","sutex");

	$Res_id = $_REQUEST["Res_id"];

	$q = mysqli_query($cn,"select * from Restaurant_Details where Res_id = '$Res_id'");
	if(mysqli_num_rows($q) == 0)
	{
		$row = array();
		print_r(json_encode($row));
	}
	else
	{
		while($row = mysqli_fetch_assoc($q))
		{
			$p[] = $row;
		}
		echo json_encode($p);
	}
?>
