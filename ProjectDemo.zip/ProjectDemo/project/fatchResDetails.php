<?php
	$cn =new mysqli("localhost","root","","sutex");

	$q = mysqli_query($cn,"select * from Restaurant_Details");
	if(mysqli_num_rows($q) == 0)
	{
		$row = array();
		print_r(json_encode($row));
	}
	else
	{
		while($row = mysqli_fetch_assoc($q))
		{
			$p[] = $row;
		}
		echo json_encode($p);
	}
?>