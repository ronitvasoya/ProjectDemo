<?php
	$cn =new mysqli("localhost","root","","sutex");
	$Cust_id = $_POST["Cust_id"];
	$Cust_name = $_POST["Cust_name"];
	$Cust_phno = $_POST["Cust_phno"];
	$Cust_city = $_POST["Cust_city"];

	$query = "update Customer_Details set Cust_name = '$Cust_name' , Cust_phno = '$Cust_phno' , Cust_city = '$Cust_city' where Cust_id = '$Cust_id'";
	$cn->query($query);
	
    $q = mysqli_query($cn,"select * from Customer_Details where Cust_id = '$Cust_id'");
    if(mysqli_num_rows($q) == 0)
    {
        $row = array();
        print_r(json_encode($row));
    }
    else
    {
        while($row = mysqli_fetch_assoc($q))
        {
            $p[] = $row;
        }
        echo json_encode($p);
    }
?>
