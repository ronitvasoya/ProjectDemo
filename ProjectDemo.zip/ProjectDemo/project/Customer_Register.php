<?php
	$cn =new mysqli("localhost","root","","sutex");
	$Cust_name = $_POST["Cust_name"];
	$Cust_phno = $_POST["Cust_phno"];
    $Cust_city = $_POST["Cust_city"];
	$Cust_email = $_POST["Cust_email"];
	$Cust_password = $_POST["Cust_password"];

	$query = "insert into Customer_Details(Cust_name,Cust_phno,Cust_email,Cust_password,Cust_city)values('$Cust_name','$Cust_phno','$Cust_email','$Cust_password','$Cust_city')";
	$cn->query($query);
    $q = mysqli_query($cn,"select * from Customer_Details where Cust_email = '$Cust_email' and Cust_password = '$Cust_password'");
    if(mysqli_num_rows($q) == 0)
    {
        $row = array();
        print_r(json_encode($row));
    }
    else
    {
        while($row = mysqli_fetch_assoc($q))
        {
            $p[] = $row;
        }
        echo json_encode($p);
    }?>
