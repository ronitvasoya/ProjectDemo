<?php
	$cn =new mysqli("localhost","root","","sutex");

	$Cust_email = $_REQUEST["Cust_email"];
	$Cust_password= $_REQUEST["Cust_password"];

    
	$q = mysqli_query($cn,"select * from Customer_Details where Cust_email = '$Cust_email' and Cust_password = '$Cust_password'");
	if(mysqli_num_rows($q) == 0)
	{
		$row = array();
		print_r(json_encode($row));
	}
	else
	{
		while($row = mysqli_fetch_assoc($q))
		{
			$p[] = $row;
		}
		echo json_encode($p);
	}
?>
