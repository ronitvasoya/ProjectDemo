<?php
	$cn =new mysqli("localhost","root","","sutex");

	$Cust_id = $_POST["Cust_id"];
	define('UPLOAD_DIR', 'Customer_image/');
	$Cust_image = $_POST["Cust_image"];

	$Cust_image = str_replace('data:image/png;base64,', '', $Cust_image);
	$Cust_image = str_replace(' ', '+', $Cust_image);
    $data = base64_decode($Cust_image);
    $file = UPLOAD_DIR . uniqid() . '.png';
    $success = file_put_contents($file, $data);

    $q = "update Customer_Details set Cust_image = '$file' where Cust_id = '$Cust_id'";
    $cn->query($q);
    $q = mysqli_query($cn,"select * from Customer_Details where Cust_id = '$Cust_id'");
    if(mysqli_num_rows($q) == 0)
    {
        $row = array();
        print_r(json_encode($row));
    }
    else
    {
        while($row = mysqli_fetch_assoc($q))
        {
            $p[] = $row;
        }
        echo json_encode($p);
    }
?>
