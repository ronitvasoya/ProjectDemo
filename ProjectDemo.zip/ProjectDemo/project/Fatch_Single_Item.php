<?php
	$cn =new mysqli("localhost","root","","sutex");

	$Item_id = $_REQUEST["Item_id"];

	$q = mysqli_query($cn,"select * from Item_Details where Item_id = '$Item_id'");
	if(mysqli_num_rows($q) == 0)
	{
		$row = array();
		print_r(json_encode($row));
	}
	else
	{
		while($row = mysqli_fetch_assoc($q))
		{
			$p[] = $row;
		}
		echo json_encode($p);
	}
?>
