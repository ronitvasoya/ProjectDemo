//
//  reslogin.swift
//  ProjectDemo
//
//  Created by MAC2 on 02/01/19.
//  Copyright © 2019 TOPS. All rights reserved.
//

import UIKit
import SwiftyButton

class reslogin: UIViewController {

    @IBOutlet weak var email: UITextField!
    @IBOutlet weak var pass: UITextField!
    
    @IBOutlet weak var btnshowhide: UIButton!
    @IBOutlet weak var reslogin: FlatButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        reslogin.frame = CGRect(x: 20, y: 350 , width: self.view.frame.width-40, height: 50)
        reslogin.color = .red
        reslogin.cornerRadius  = 5
        //reslogin.isEnabled = false
        pass.isSecureTextEntry = true;
        createnavbar()
        
    }
    
    @IBAction func resloginAction(_ sender: Any) {
        
        
    }
    @IBAction func btnshowhide(_ sender: UIButton)
    {
        if btnshowhide.titleLabel?.text == "Show"
        {
            pass.isSecureTextEntry = false
            btnshowhide.setImage(UIImage(named: "if_eye_1545742.png"), for: .normal)
            btnshowhide.setTitle("Hide", for: .normal)
        }
        else
        {
            pass.isSecureTextEntry = true
            btnshowhide.setImage(UIImage(named: "if_icon-21-eye-hidden_314858.png"), for: .normal)
            btnshowhide.setTitle("Show", for: .normal)
        }
    }
    
    func createnavbar()
    {
        let btn = UIButton(type:  .custom)
        btn.setImage(UIImage(named: "cross16.png"), for: .normal)
        btn.addTarget(self, action: #selector(self.test(_:)), for: .touchDown)
        btn.frame = CGRect(x: 15, y: 40, width: 30, height: 30)
        self.view.addSubview(btn)
    }
    func test(_ sender:UIButton) {
        navigationController?.popViewController(animated: true)
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
}
