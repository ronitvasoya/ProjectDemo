//
//  home.swift
//  ProjectDemo
//
//  Created by MAC2 on 13/12/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit
import EasySocialButton
import  FBSDKLoginKit
import GoogleSignIn

class home: UIViewController,FBSDKLoginButtonDelegate,GIDSignInUIDelegate, GIDSignInDelegate {
    
    @IBOutlet weak var subview: UIView!
    
    //  @IBOutlet weak var btn: UIButton!
    @IBOutlet weak var imgview: UIImageView!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationController?.navigationBar.isHidden = true
        
        imgview.frame = CGRect(x: 0, y: 0, width: self.view.frame.width, height: self.view.frame.height)
        
        self.subview.frame = CGRect(x: 0, y: self.view.frame.height - 330 , width: self.view.frame.width, height: 330)
        self.subview.layer.masksToBounds = false;
        self.subview.layer.opacity = 0.9
        self.subview.layer.shadowOffset = CGSize(width: 2, height: 2)
        self.subview.layer.shadowOpacity = 0.9
        
        let diff = UserDefaults.standard
        if (diff.value(forKey: "Username") != nil)
        {
            let stb = self.storyboard?.instantiateViewController(withIdentifier: "userhome")
            
            self.navigationController?.pushViewController(stb!, animated: true)
        }
    
        let label = UILabel(frame: CGRect(x: 60, y: 260, width: 300, height: 20))
        label.text = "By logging in you agree to Food";
        
        let label1 = UILabel(frame: CGRect(x: 75, y: 285, width: 300, height: 20))
        label1.text = "Vector's";
        self.subview.addSubview(label);
        self.subview.addSubview(label1);
        
        createFacebookBtn()
        createGmailBtn()
        createEmailBtn()
        LoginlaterBtn()
        TnCBtn()
        createnavbar()
    }
    
    func createFacebookBtn(){
        let loginButton = FBSDKLoginButton(frame: CGRect(x: 35, y: 30, width: 300, height: 40))
        loginButton.readPermissions = ["email"]
        self.subview.addSubview(loginButton)
        loginButton.delegate = self
    }
    
    func createGmailBtn() {
        let signInButton = GIDSignInButton(frame: CGRect(x: 35, y: 100, width: 300, height: 40))
        GIDSignIn.sharedInstance().delegate = self
        GIDSignIn.sharedInstance().uiDelegate = self
        signInButton.style = .wide
    NotificationCenter.default.addObserver(self,selector:#selector(self.receiveToggleAuthUINotification(_:)),name: NSNotification.Name(rawValue: "ToggleAuthUINotification"),object:nil)
        self.subview.addSubview(signInButton);
    }
    
   func createEmailBtn()
   {
    let socialButton2 = AZSocialButton(frame: CGRect(x: 35, y: 170, width: 300, height: 40))
    socialButton2.animateInteraction = true
    socialButton2.useCornerRadius = true
    socialButton2.cornerRadius = 5
    socialButton2.highlightOnTouch = false
    socialButton2.setImage(UIImage(named: "email.png"), for: .normal)
    socialButton2.setTitle("    Sign in with Email", for: [])
    socialButton2.setTitleColor(.black, for: [])
    socialButton2.titleLabel?.font = UIFont.systemFont(ofSize: 20)
    socialButton2.onClickAction = { (button) in
        
        let stb = self.storyboard?.instantiateViewController(withIdentifier: "login")
        self.navigationController?.pushViewController(stb!, animated: true)
        
    }
    self.subview.addSubview(socialButton2);
    
    }
    func LoginlaterBtn() {
        let btn = UIButton()
        btn.frame = CGRect(x: 95, y: 225, width: 200, height: 30)
        btn.setTitle("I'll log in later", for: .normal)
        btn.setTitleColor(UIColor.blue, for: .normal)
        btn.addTarget(self, action: #selector(self.test), for: .touchDown)
        self.subview.addSubview(btn);
    }
    
    func TnCBtn() {
        let btn1 = UIButton()
        btn1.frame = CGRect(x: 115, y: 285, width: 200, height: 20)
        btn1.setTitle("Terms & Condition", for: .normal)
        btn1.setTitleColor(UIColor.blue, for: .normal)
        btn1.addTarget(self, action: #selector(self.test1), for: .touchDown)
        self.subview.addSubview(btn1);
    }
    
    func test(sender:UIButton) {
        let stb = self.storyboard?.instantiateViewController(withIdentifier: "userhome")
        self.navigationController?.pushViewController(stb!, animated: true)
        
    }
    
    func test1(sender:UIButton) {
        let stb = self.storyboard?.instantiateViewController(withIdentifier: "t&c")
        self.navigationController?.pushViewController(stb!, animated: true)
    }
    
    func createnavbar()
    {
        let btn = UIButton(type:  .custom)
        btn.setImage(UIImage(named: "blackcross.png"), for: .normal)
        btn.addTarget(self, action: #selector(close(_:)), for: .touchDown)
        btn.frame = CGRect(x: 15, y: 40, width: 30, height: 30)
        self.view.addSubview(btn)
    }
    
   @objc func close(_ sender : UIButton)
   {
        self.navigationController?.popViewController(animated: true)
    }
    
    func loginButton(_ loginButton: FBSDKLoginButton!, didCompleteWith result: FBSDKLoginManagerLoginResult!, error: Error!) {
       print("Login Successfully")
        getFBUserData()
    }
    
    func loginButtonWillLogin(_ loginButton: FBSDKLoginButton!) -> Bool {
        return true
    }
    
    func loginButtonDidLogOut(_ loginButton: FBSDKLoginButton!) {
        print("user Logedout")
    }
    
    func getFBUserData() {
        let graphRequest = FBSDKGraphRequest(graphPath: "me", parameters: ["fields":"id, email, name, picture.width(480).height(480)"])
        graphRequest?.start(completionHandler: { (connection, result, error) in
            if error != nil {
                print("Error",error!.localizedDescription)
            
            }
            else{
                print(result!)
                let field = result! as? [String:Any]
                let diff = UserDefaults.standard
                diff.set(field?["name"] as! String, forKey: "Username")
                let stb = self.storyboard?.instantiateViewController(withIdentifier: "userhome")
                
                self.navigationController?.pushViewController(stb!, animated: true)

                //self.userNameLabel.text = "Hello" + (field?["name"] as! String)
                //print("Hello" + (field?["name"] as! String))
                
                /*if let imageURL = ((field!["picture"] as? [String: Any])?["data"] as? [String: Any])?["url"] as? String {
                    print(imageURL)
                    let url = URL(string: imageURL)
                    let data = NSData(contentsOf: url!)
                    let image = UIImage(data: data! as Data)
                }*/
            }
        })
        
    }
    
    @objc func receiveToggleAuthUINotification(_ notification: NSNotification) {
        if notification.name.rawValue == "ToggleAuthUINotification" {
            if notification.userInfo != nil {
                guard let userInfo = notification.userInfo as? [String:String] else { return }
            }
        }
    }
    
    func sign(_ signIn: GIDSignIn!, didSignInFor user: GIDGoogleUser!,
              withError error: Error!) {
        if let error = error {
            print("\(error.localizedDescription)")
            // [START_EXCLUDE silent]
            NotificationCenter.default.post(
                name: Notification.Name(rawValue: "ToggleAuthUINotification"), object: nil, userInfo: nil)
            // [END_EXCLUDE]
        } else {
            // Perform any operations on signed in user here.
            let userId = user.userID                  // For client-side use only!
            let idToken = user.authentication.idToken // Safe to send to the server
            let fullName = user.profile.name
            let givenName = user.profile.givenName
            let familyName = user.profile.familyName
            let email = user.profile.email
           // let Image_Url = user.profile.imageURL(withDimension: UInt(0.6))
            let diff = UserDefaults.standard
            diff.set(fullName, forKey: "Username")
            diff.set(email, forKey: "email")
            let stb = self.storyboard?.instantiateViewController(withIdentifier: "userhome")
            
            self.navigationController?.pushViewController(stb!, animated: true)
            print(userId!)
            print(idToken!)
            print(fullName!)
            print(givenName!)
            print(familyName!)
            print(email!)
            //print(Image_Url!)
            
            // [START_EXCLUDE]
            NotificationCenter.default.post(
                name: Notification.Name(rawValue: "ToggleAuthUINotification"),
                object: nil,
                userInfo: ["statusText": "Signed in user:\n\(String(describing: fullName))"])
            // [END_EXCLUDE]
        }
    }
}
