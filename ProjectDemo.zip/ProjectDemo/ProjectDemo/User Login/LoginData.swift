import UIKit

class LoginData: NSObject {

    func getData() -> [String:String] {
        let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let strpath = path[0]
        let fullpath = strpath.appending("/profile.plist")
    
        let fmg = FileManager()
        var dic:[String:String] = [:]
        if fmg.fileExists(atPath: fullpath)
        {
            dic = NSDictionary(contentsOfFile: fullpath) as! [String : String]
        }
        return dic
    }
    
    func insertData(dic:[String:String]) {
        let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let strpath = path[0]
        let fullpath = strpath.appending("/profile.plist")
        let finaldic = NSDictionary(dictionary: dic)
        finaldic.write(toFile: fullpath, atomically: true)
    }
    
    func deleteData(dic:[String:String]) {
        let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let strpath = path[0]
        let fullpath = strpath.appending("/profile.plist")
        let finaldic = NSDictionary(dictionary: dic)
        finaldic.write(toFile: fullpath, atomically: true)
    }
    
}
