//
//  T&C.swift
//  ProjectDemo
//
//  Created by MAC2 on 26/12/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class T_C: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        createnavbar()
        
    }
    func createnavbar() {
        
        let btn = UIButton(type:  .custom)
        btn.setImage(UIImage(named: "cross16.png"), for: .normal)
        btn.addTarget(self, action: #selector(self.test(_:)), for: .touchDown)
        btn.frame = CGRect(x: 15, y: 40, width: 30, height: 30)
        self.view.addSubview(btn)
    }

    func test(_ sender:UIButton) {
        navigationController?.popViewController(animated: true)
    }

}
