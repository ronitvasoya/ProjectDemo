//
//  T&C.swift
//  ProjectDemo
//
//  Created by MAC2 on 26/12/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit
import MapKit

/*class CustomPin:NSObject ,MKAnnotation{
    var coordinate: CLLocationCoordinate2D
    var tital:String?
    var subtital:String?
    
    init(pinTital:String , pinSubTital:String , location:CLLocationCoordinate2D) {
        self.tital = pinTital
        self.subtital = pinSubTital
        self.coordinate = location
    }
    
}*/

class T_C: UIViewController ,MKMapViewDelegate{

    @IBOutlet weak var txtview: UITextView!
    override func viewDidLoad() {
        super.viewDidLoad()
        createnavbar()
    }
    
    /*func setDirection() {
        let sourceLocation = CLLocationCoordinate2D(latitude: 21.170240, longitude: 72.831062)
        let destinationLocation = CLLocationCoordinate2D(latitude: 21.705135, longitude: 72.995872)
        let sourcepin = CustomPin(pinTital: "Surat", pinSubTital: "", location: sourceLocation)
        let destinationpin = CustomPin(pinTital: "Bharuch", pinSubTital: "", location: destinationLocation)
        
        self.map.addAnnotation(sourcepin)
        self.map.addAnnotation(destinationpin)
        let sourceplaceMark = MKPlacemark(coordinate: sourceLocation)
        let DestinationplaceMark = MKPlacemark(coordinate: destinationLocation)
        
        let directionrequest = MKDirectionsRequest()
        directionrequest.source = MKMapItem(placemark: sourceplaceMark)
        directionrequest.destination = MKMapItem(placemark: DestinationplaceMark)
        directionrequest.transportType = .automobile
        
        let center = CLLocationCoordinate2D(latitude: 21.170240, longitude: 72.831062)
        let region = MKCoordinateRegion(center: center, span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01))
        self.map.setRegion(region, animated: true)
        let direction = MKDirections(request: directionrequest)
        direction.calculate { (response, error) in
            guard let directionResponse = response else {
                if let error  = error {
                    print("we have error getting direction = \(error.localizedDescription)")
                }
                return
            }
            
            let route = directionResponse.routes[0]
            self.map.add(route.polyline, level: .aboveRoads)
            
            let rect = route.polyline.boundingMapRect
            self.map.setRegion(MKCoordinateRegionForMapRect(rect), animated: true)
        }
        self.map.delegate = self
    }
    
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        let renderer = MKPolylineRenderer(overlay: overlay)
        renderer.strokeColor = UIColor.blue
        renderer.lineWidth = 4.0
        return renderer
    }*/
    
    func createnavbar() {
        
        let btn = UIButton(type:  .custom)
        btn.setImage(UIImage(named: "cross16.png"), for: .normal)
        btn.addTarget(self, action: #selector(self.test(_:)), for: .touchDown)
        btn.frame = CGRect(x: 15, y: 30, width: 30, height: 30)
        self.view.addSubview(btn)
    }

    func test(_ sender:UIButton) {
        navigationController?.popViewController(animated: true)
    }

}
