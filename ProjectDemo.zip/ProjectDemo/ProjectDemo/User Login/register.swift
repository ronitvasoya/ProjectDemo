//
//  register.swift
//  ProjectDemo
//
//  Created by TOPS on 10/15/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit
import TextFieldEffects
import TransitionButton
import SwiftyButton

var obj = validation()
var name:Bool = false
var regemail:Bool = false
var regpass:Bool = false
var phno:Bool = false
var city:Bool = false
class register: UIViewController {

    @IBOutlet weak var register: FlatButton!
    @IBOutlet weak var subview: UIView!
    @IBOutlet weak var txtname: UITextField!
    @IBOutlet weak var txtphno: UITextField!
    @IBOutlet weak var txtemail: UITextField!
    @IBOutlet weak var txtcity: UITextField!
    @IBOutlet weak var txtpass: UITextField!
    
    @IBOutlet weak var btnshowhide: UIButton!
    @IBOutlet weak var img: UIImageView!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()

        navigationController?.navigationBar.isHidden = true
        
        img.frame = CGRect(x: 0, y: 0, width: self.view.frame.width, height: self.view.frame.height)
        subview.frame = CGRect(x: 0, y: 0, width: self.view.frame.width, height: self.view.frame.height)
        
        self.subview.layer.masksToBounds = false;
        self.subview.layer.opacity = 1
        self.subview.layer.shadowOffset = CGSize(width: 2, height: 2)
        self.subview.layer.shadowOpacity = 1
        
        register.frame = CGRect(x: 20, y: 518, width: self.view.frame.width-40, height: 50)
        register.color = .red
        register.cornerRadius = 5
        register.isEnabled = false
        createnavbar()
    }

    @IBAction func registeraction(_ sender: Any) {
        
        if txtemail.text != "" && txtphno.text != "" && txtname.text != "" && txtpass.text != "" && txtcity.text != "" {
            
            if obj.isValidEmail(email: txtemail.text!) {
                
                if obj.isValidName(name: txtname.text!){
                    
                    if obj.isValidMobile(mobile: txtphno.text!) {
                        
                        if obj.isValidPassword(pwd: txtpass.text!){
                            
                            let url = URL(string: "http://localhost/project/Check_Email.php?Cust_email=\(txtemail.text!)");
                            let request = URLRequest(url: url!);
                            let session = URLSession.shared;
                            let datatask = session.dataTask(with: request)
                            {
                                (data1, rsp, err) in
                                DispatchQueue.main.async
                                    {
                                        do
                                        {
                                            var jsondata = try JSONSerialization.jsonObject(with: data1!, options: []) as! [Any];
                                            if jsondata.count > 0
                                            {
                                                let alert = UIAlertController(title: "Alert", message: "Email Is Already Registered Please Try To Login", preferredStyle: .alert);
                                                let ok = UIAlertAction(title: "Ok", style: .default)
                                                {
                                                    ACTION in
                                                    
                                                }
                                                alert.addAction(ok);
                                                self.present(alert, animated: true, completion: nil);
                                            }
                                            else
                                            {
                                                self.Register()
                                            }
                                        }
                                        catch
                                        {
                                        }
                                }
                            }
                            datatask.resume();
                        }else {
                            
                            print("Enter valid password!")
                        }
                    }else {
                        
                        print("Enter valid mobile!")
                    }
                }else {
                    
                    print("Enter valid phone!")
                }
            }else {
                
                print("Enter valid e_mail!")
            }
        }
        else {
            
            print("Kindly enter fully detail")
        }

        
    }
    
    func Register() {
        let url = URL(string: "http://localhost/project/Customer_Register.php")
        let strBody = "Cust_name=\(txtname.text!)&Cust_phno=\(txtphno.text!)&Cust_city=\(txtcity.text!)&Cust_email=\(txtemail.text!)&Cust_password=\(txtpass.text!)"
        var request = URLRequest(url: url!);
        request.addValue(String(strBody.count), forHTTPHeaderField: "Content_Length")
        request.httpBody = strBody.data(using: String.Encoding.utf8)
        request.httpMethod = "POST"
        let session = URLSession.shared;
        let datatask = session.dataTask(with: request)
        {
            (data1, rsp, err) in
            DispatchQueue.main.async {
                
                do
                {
                    var jsondata = try JSONSerialization.jsonObject(with: data1!, options: []) as! [Any];
                    if jsondata.count > 0
                    {
                        var dic = jsondata[0] as! [String:String]
                        loginObj.insertData(dic: dic)
                        let dif = UserDefaults.standard;
                        dif.set(dic["Cust_name"], forKey: "Username")
                        dif.set(Int(dic["Cust_id"]!), forKey: "Cust_id")
                        let stb = self.storyboard?.instantiateViewController(withIdentifier: "userhome")
                        self.navigationController?.pushViewController(stb!, animated: true)
                    }
                }catch{}
            }
        }
        datatask.resume();
    }
    
    func check(name:Bool, regemail:Bool , regpass:Bool , phno:Bool , city:Bool) {
        
        if regemail == true && regpass == true && name == true && phno == true && city == true
        {
            register.isEnabled = true
        }
        else
        {
            register.isEnabled = false
        }
        
    }
    
    @IBAction func txtname(_ sender: Any)
    {
        if obj.isValidName(name: txtname.text!)
        {
            txtname.rightViewMode = .never
            name = true
        }
        else
        {
            txtname.rightViewMode = .whileEditing
            let imgview = UIImageView(image: UIImage(named: "help.png"))
            txtname.rightView = imgview
            name = false
        }
        check(name: name, regemail: regemail, regpass: regpass, phno: phno, city: city)
    }
    @IBAction func txtphno(_ sender: Any)
    {
        if obj.isValidMobile(mobile: txtphno.text!)
        {
            txtphno.rightViewMode = .never
            phno = true
        }
        else
        {
            txtphno.rightViewMode = .whileEditing
            let imgview = UIImageView(image: UIImage(named: "help.png"))
            txtphno.rightView = imgview
            phno = false
        }
        check(name: name, regemail: regemail, regpass: regpass, phno: phno, city: city)
    }
    @IBAction func txtcity(_ sender: Any) {
        if obj.isValidName(name: txtcity.text!)
        {
            txtcity.rightViewMode = .never
            city = true
        }
        else
        {
            txtcity.rightViewMode = .whileEditing
            let imgview = UIImageView(image: UIImage(named: "help.png"))
            txtcity.rightView = imgview
            city = false
        }
        check(name: name, regemail: regemail, regpass: regpass, phno: phno, city: city)
    }
    @IBAction func txtemail(_ sender: Any)
    {
        if obj.isValidEmail(email: txtemail.text!)
        {
            txtemail.rightViewMode = .never
            regemail = true
        }
        else
        {
            txtemail.rightViewMode = .whileEditing
            let imgview = UIImageView(image: UIImage(named: "help.png"))
            txtemail.rightView = imgview
            regemail = false
        }
        check(name: name, regemail: regemail, regpass: regpass, phno: phno, city: city)
    }
    @IBAction func txtpass(_ sender: Any)
    {
        if obj.isValidPassword(pwd: txtpass.text!)
        {
            txtpass.rightViewMode = .never
            regpass = true
        }
        else
        {
            txtpass.rightViewMode = .whileEditing
            let imgview = UIImageView(image: UIImage(named: "help.png"))
            txtpass.rightView = imgview
            regpass = false
        }
        check(name: name, regemail: regemail, regpass: regpass, phno: phno, city: city)
    }
    
    @IBAction func btnshowhide(_ sender: UIButton)
    {
        if btnshowhide.titleLabel?.text == "Show"
        {
            txtpass.isSecureTextEntry = false
            btnshowhide.setImage(UIImage(named: "if_eye_1545742.png"), for: .normal)
            btnshowhide.setTitle("Hide", for: .normal)
        }
        else
        {
            txtpass.isSecureTextEntry = true
            btnshowhide.setImage(UIImage(named: "if_icon-21-eye-hidden_314858.png"), for: .normal)
            btnshowhide.setTitle("Show", for: .normal)
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?)
    {
        self.view.endEditing(true)
    }

    func createnavbar()
    {
        let btn = UIButton(type:  .custom)
        btn.setImage(UIImage(named: "cross16.png"), for: .normal)
        btn.addTarget(self, action: #selector(self.test(_:)), for: .touchDown)
        btn.frame = CGRect(x: 15, y: 40, width: 30, height: 30)
        self.view.addSubview(btn)
    }
    
    func test(_ sender:UIButton)
    {
        navigationController?.popViewController(animated: true)
    }
    
   
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    


}
