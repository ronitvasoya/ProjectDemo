//
//  fp.swift
//  ProjectDemo
//
//  Created by MAC2 on 27/12/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit
var obj2 = validation()

class fp: UIViewController {

    @IBOutlet weak var txtemail: UITextField!
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        createnavbar()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func txtemail(_ sender: Any)
    {
        if obj2.isValidEmail(email: txtemail.text!)
        {
            txtemail.rightViewMode = .never
           // txtemail.clipsToBounds = true
            //txtemail.layer.borderWidth = 1
            //txtemail.layer.borderColor = UIColor.green.cgColor
        }
        else
        {
            txtemail.rightViewMode = .whileEditing
            let imgview = UIImageView(image: UIImage(named: "help.png"))
            txtemail.rightView = imgview
            //txtemail.clipsToBounds = true
            //txtemail.layer.borderWidth = 1
            //txtemail.layer.borderColor = UIColor.red.cgColor
        }
    }
    func createnavbar()
    {
        let btn = UIButton(type:  .custom)
        btn.setImage(UIImage(named: "cross16.png"), for: .normal)
        btn.addTarget(self, action: #selector(self.test(_:)), for: .touchDown)
        btn.frame = CGRect(x: 15, y: 40, width: 30, height: 30)
        self.view.addSubview(btn)
    }
    
    func test(_ sender:UIButton)
    {
            navigationController?.popViewController(animated: true)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
