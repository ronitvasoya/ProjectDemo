//
//  AddressPlist.swift
//  ProjectDemo
//
//  Created by MAC2 on 27/02/19.
//  Copyright © 2019 TOPS. All rights reserved.
//

import UIKit

class AddressPlist: NSObject {

    var Address:[String:String] = [:]
    
    func getData() -> [String:String] {
        let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let strpath = path[0]
        let fullpath = strpath.appending("/Address.plist")
        print(fullpath)
        let fmg = FileManager()
        if fmg.fileExists(atPath: fullpath)
        {
            Address = NSDictionary(contentsOfFile: fullpath) as! [String : String]
        }
        return Address
    }
    
    func insertData(Address : [String : String]) {
        let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let strpath = path[0]
        let fullpath = strpath.appending("/Address.plist")
        let finaldic = NSDictionary(dictionary: Address)
        finaldic.write(toFile: fullpath, atomically: true)
    }
    
    func DeleteData()  {
        let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let strpath = path[0]
        let fullpath = strpath.appending("/Address.plist")
        Address.removeAll()
        let finaldic = NSDictionary(dictionary: Address)
        finaldic.write(toFile: fullpath, atomically: true)

    }
}
