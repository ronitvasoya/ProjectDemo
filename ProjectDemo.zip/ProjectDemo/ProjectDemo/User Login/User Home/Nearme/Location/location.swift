//
//  location.swift
//  ProjectDemo
//
//  Created by Ronit Vasoya on 25/02/19.
//  Copyright © 2019 TOPS. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation
import SwiftyButton

class location: UIViewController,CLLocationManagerDelegate {

    @IBOutlet weak var map: MKMapView!
    @IBOutlet weak var btnAddMoreDetails: FlatButton!
    @IBOutlet weak var lblAddress: UILabel!
    @IBOutlet weak var btnConfAddress: FlatButton!
    
    let locationmanger = CLLocationManager()
    var lat = 0.0
    var log = 0.0
    var Address:String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        map.showsUserLocation = true
        if CLLocationManager.locationServicesEnabled() {
            switch(CLLocationManager.authorizationStatus()) {
            case .notDetermined, .restricted, .denied:
                print("No access")
            case .authorizedAlways, .authorizedWhenInUse:
                print("Access")
            }
        } else {
            print("Location services are not enabled")
        }
        locationmanger.delegate = self;
        locationmanger.desiredAccuracy = kCLLocationAccuracyHundredMeters;
        
        locationmanger.requestWhenInUseAuthorization();
        locationmanger.requestAlwaysAuthorization();
        locationmanger.startUpdatingLocation();
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        let cls =   locations[0];
        lat =   cls.coordinate.latitude;
        log  = cls.coordinate.longitude;
        print(lat);
        print(log);
        
        CLGeocoder().reverseGeocodeLocation(cls, completionHandler: {(placemarks, error) -> Void in
            
            if error != nil {
                print("Reverse geocoder failed with error" + (error?.localizedDescription)!)
                return
            }
            
            if (placemarks?.count)! > 0 {
                self.Address = ""
                let pm = placemarks?[0]
                self.Address += (pm?.name)! + ", "
                self.Address += (pm?.subLocality)! + ", "
                self.Address += (pm?.postalCode)! + ", "
                self.Address += (pm?.locality)!
                /*print(pm?.locality!)
                print(pm?.country!)
                print(pm?.postalCode!)
                print(pm?.name!)
                print(pm?.subLocality!)
                print(pm?.ocean!)*/
                self.lblAddress.text = self.Address
                print(self.Address)
            }
            else {
                print("Problem with the data received from geocoder")
            }
        })
        locationmanger.stopUpdatingLocation();
        
        let center = CLLocationCoordinate2D(latitude: cls.coordinate.latitude, longitude: cls.coordinate.longitude)
        let region = MKCoordinateRegion(center: center, span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01))
        self.map.setRegion(region, animated: true)
        let Location = CLLocationCoordinate2DMake(lat, log)
        let dropPin = MKPointAnnotation()
        dropPin.coordinate = Location
        //dropPin.title = "New York City"
        map.addAnnotation(dropPin)
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func addMoreDetails(_ sender: UIButton) {
        
    }
    
    @IBAction func btnConfAddress(_ sender: UIButton) {
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        navigationController?.navigationBar.isHidden = false
        tabBarController?.tabBar.isHidden = true
    }
}
