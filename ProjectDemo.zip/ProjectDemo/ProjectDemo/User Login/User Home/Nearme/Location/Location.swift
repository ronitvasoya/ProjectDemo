//
//  location.swift
//  ProjectDemo
//
//  Created by Ronit Vasoya on 25/02/19.
//  Copyright © 2019 TOPS. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation
import SwiftyButton
import TextFieldEffects

class location: UIViewController,CLLocationManagerDelegate {

    @IBOutlet weak var map: MKMapView!
    @IBOutlet weak var btnAddMoreDetails: FlatButton!
    @IBOutlet weak var lblAddress: UILabel!
    @IBOutlet weak var btnConfAddress: FlatButton!
    
    let locationmanger = CLLocationManager()
    var lat = 0.0
    var log = 0.0
    var AddressStr:String = ""
    var Address:[String:String] = [:]
    var AddressObj = AddressPlist()
    var subview = UIView()
    var subviewlblAddress = UILabel()
    var hidesubview:Bool = true
    var time = Timer()
    var  s = 0.0
    var txthomeNo = HoshiTextField()
    var txtlandmark = HoshiTextField()
    var btnsave = FlatButton()
    let width = CGFloat(2.0)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        btnAddMoreDetails.color = .red
        btnConfAddress.color = .red
        btnAddMoreDetails.cornerRadius = 5
        btnConfAddress.cornerRadius = 5
        setLocation()
        CreateSubview()
        let border = CALayer()
        border.borderColor = UIColor.darkGray.cgColor
        border.frame = CGRect(x: 0, y: lblAddress.frame.height-width, width: lblAddress.frame.width, height: lblAddress.frame.height)
        border.borderWidth = width
        lblAddress.layer.addSublayer(border)
        lblAddress.layer.masksToBounds = true
    }
    
    func setLocation() {
        map.showsUserLocation = true
        if CLLocationManager.locationServicesEnabled() {
            switch(CLLocationManager.authorizationStatus()) {
            case .notDetermined, .restricted, .denied:
                print("No access")
            case .authorizedAlways, .authorizedWhenInUse:
                print("Access")
            }
        } else {
            print("Location services are not enabled")
        }
        locationmanger.delegate = self;
        locationmanger.desiredAccuracy = kCLLocationAccuracyHundredMeters;
        
        locationmanger.requestWhenInUseAuthorization();
        locationmanger.requestAlwaysAuthorization();
        locationmanger.startUpdatingLocation();
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        let cls =   locations[0];
        lat =   cls.coordinate.latitude;
        log  = cls.coordinate.longitude;
        print(lat);
        print(log);
        
        CLGeocoder().reverseGeocodeLocation(cls, completionHandler: {(placemarks, error) -> Void in
            
            if error != nil {
                print("Reverse geocoder failed with error" + (error?.localizedDescription)!)
                return
            }
            
            if (placemarks?.count)! > 0 {
                self.AddressStr = ""
                let pm = placemarks?[0]
                self.AddressStr += (pm?.name)! + ", "
                self.AddressStr += (pm?.subLocality)! + ", "
                self.AddressStr += (pm?.postalCode)! + ", "
                self.AddressStr += (pm?.locality)!
                /*print(pm?.locality!)
                print(pm?.country!)
                print(pm?.postalCode!)
                print(pm?.name!)
                print(pm?.subLocality!)
                print(pm?.ocean!)*/
                self.lblAddress.text = self.AddressStr
                self.subviewlblAddress.text = self.AddressStr
                self.Address["Address"] = self.AddressStr
            }
            else {
                print("Problem with the data received from geocoder")
            }
        })
        locationmanger.stopUpdatingLocation();
        
        let center = CLLocationCoordinate2D(latitude: cls.coordinate.latitude, longitude: cls.coordinate.longitude)
        let region = MKCoordinateRegion(center: center, span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01))
        self.map.setRegion(region, animated: true)
        let Location = CLLocationCoordinate2DMake(lat, log)
        let dropPin = MKPointAnnotation()
        dropPin.coordinate = Location
        //dropPin.title = "New York City"
        map.addAnnotation(dropPin)
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func addMoreDetails(_ sender: UIButton) {
        show()
    }
    
    @IBAction func btnConfAddress(_ sender: UIButton) {
        self.AddressObj.insertData(Address: self.Address)
        navigationController?.popViewController(animated: true)
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        navigationController?.navigationBar.isHidden = false
        tabBarController?.tabBar.isHidden = true
        lblAddress.text = "Identifying Location..."
        hide()
    }
    
    func CreateSubview() {
        subview.frame = CGRect(x: 0, y: self.view.frame.height+50, width: self.view.frame.width, height: 300)
        let lblsetlocation = UILabel(frame: CGRect(x: 15, y: 15, width: self.view.frame.width-75, height: 25))
        let btncancel = UIButton(frame: CGRect(x: self.view.frame.width-45, y: 15, width: 30, height: 30))
        let lblLOCATION = UILabel(frame: CGRect(x: 15, y: 55, width: 150, height: 20))
        subviewlblAddress.frame = CGRect(x: 15, y: 80, width: self.view.frame.width-30, height: 25)
        txthomeNo.frame = CGRect(x: 15, y: 115, width: self.view.frame.width-30, height: 50)
        txtlandmark.frame = CGRect(x: 15, y: 175, width: self.view.frame.width-30, height: 50)
        btnsave.frame = CGRect(x: 20, y: 235, width: self.view.frame.width-40, height: 53)
        
        btncancel.addTarget(self, action: #selector(self.test1(_:)), for: .touchDown)
        btnsave.addTarget(self, action: #selector(self.test2(_:)), for: .touchDown)
        
        lblsetlocation.text = "Set Delivery Location"
        lblsetlocation.font = UIFont.boldSystemFont(ofSize: 20.0)
        let border = CALayer()
        border.frame = CGRect(x: 0, y: subviewlblAddress.frame.height-width, width: subviewlblAddress.frame.width, height: subviewlblAddress.frame.height)
        border.borderWidth = width
        subviewlblAddress.layer.addSublayer(border)
        subviewlblAddress.layer.masksToBounds = true
        btncancel.setImage(UIImage(named: "cross16"), for: .normal)
        lblLOCATION.text = "LOCATION"
        lblLOCATION.textColor = UIColor.gray
        lblLOCATION.font = UIFont.systemFont(ofSize: 15.0)
        txthomeNo.placeholder = "HOUSE / FLAT NO."
        
        txthomeNo.borderActiveColor = #colorLiteral(red: 0, green: 0.5898008943, blue: 1, alpha: 1)
        txthomeNo.placeholderColor = UIColor.darkText
        txthomeNo.borderInactiveColor = #colorLiteral(red: 0, green: 0.5898008943, blue: 1, alpha: 1)
        txtlandmark.placeholder = "LANDMARK"
        txtlandmark.borderActiveColor = #colorLiteral(red: 0, green: 0.5898008943, blue: 1, alpha: 1)
        txtlandmark.placeholderColor = UIColor.darkText
        txtlandmark.borderInactiveColor = #colorLiteral(red: 0, green: 0.5898008943, blue: 1, alpha: 1)
        subview.backgroundColor = UIColor.white
        btnsave.cornerRadius = 5
        btnsave.color = UIColor.red
        btnsave.setTitle("Save", for: .normal)
        btnsave.titleLabel?.font = UIFont.systemFont(ofSize: 30.0)
        
        subview.addSubview(lblsetlocation)
        subview.addSubview(btncancel)
        subview.addSubview(lblLOCATION)
        subview.addSubview(subviewlblAddress)
        subview.addSubview(txtlandmark)
        subview.addSubview(txthomeNo)
        subview.addSubview(btnsave)
        self.view.addSubview(subview)
    }
    
    @objc func hide() {
        s = 0.3
        time = Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(self.test(_:)), userInfo: nil, repeats: true)
        UIView.beginAnimations(nil, context: nil)
        UIView.setAnimationDuration(0.3)
        UIView.setAnimationDelegate(self)
        subview.frame = CGRect(x: 0, y: self.view.frame.height+50, width: self.view.frame.width, height: 300)
        UIView.commitAnimations()
        hidesubview = false
    }
    
    @objc func show() {
        s = 0.0
        time = Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(self.test(_:)), userInfo: nil, repeats: true)
        UIView.beginAnimations(nil, context: nil)
        UIView.setAnimationDuration(0.3)
        UIView.setAnimationDelegate(self)
        subview.frame = CGRect(x: 0, y: self.view.frame.height-300, width: self.view.frame.width, height: 300)
        UIView.commitAnimations()
        hidesubview = true
    }
    
    @objc func test(_ sender:Timer) {
        if hidesubview == false
        {
            if s <= 0.3
            {
                s = s + 0.1
            }
            else
            {
                time.invalidate()
            }
        }
        else
        {
            if s >= 0.0
            {
                s = s - 0.1
                
            }
            else
            {
                time.invalidate()
            }
        }
    }
    
    func test1(_ sender:UIButton) {
        hide()
    }
    
    func test2(_ sender:UIButton) {
        AddressStr = txthomeNo.text! + ", " + txtlandmark.text! + ", " + AddressStr
        Address["Address"] = AddressStr
        AddressObj.insertData(Address: Address)
        navigationController?.popViewController(animated: true)
    }
}
