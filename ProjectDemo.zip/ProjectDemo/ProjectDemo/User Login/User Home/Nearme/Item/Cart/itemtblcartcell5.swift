//
//  itemtblcartcell5.swift
//  ProjectDemo
//
//  Created by Ronit Vasoya on 20/02/19.
//  Copyright © 2019 TOPS. All rights reserved.
//

import UIKit

class itemtblcartcell5: UITableViewCell {

    @IBOutlet weak var lbloffercode: UILabel!
    @IBOutlet weak var lblitemtotal: UILabel!
    @IBOutlet weak var lblofferamt: UILabel!
    @IBOutlet weak var lblgrandtotal: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
