//
//  itemcart.swift
//  ProjectDemo
//
//  Created by MAC2 on 15/02/19.
//  Copyright © 2019 TOPS. All rights reserved.
//

import UIKit
import SwiftyButton

class itemcart: UIViewController,UITableViewDelegate,UITableViewDataSource
{
    var Cartplist:[Any] = []
    var item_Id:[Int] = []
    var item_Qty:[Int] = []
    var item_Price:[Int] = []
    var cartobj = CartData()
    var Res_id:Int = 0
    var Res_image:String = ""
    var Res_name:String = ""
    var itemdetails:[[String:String]] = [[:]]
    var Item_total:Double = 0.0
    var Grand_total:Double = 0.0
    var temp:Bool = false
    var Is_veg:[Int] = []
    var Offer_details:[String : String] = [:]
    var Offer_amt:Int = 0
    var OfferDataObj = OfferData()
    
    @IBOutlet weak var btnpayment: FlatButton!
    @IBOutlet weak var tblitem: UITableView!
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        btnpayment.color = .red
        btnpayment.cornerRadius = 5
        btnpayment.frame =  CGRect(x: 20, y: self.view.frame.height-60, width: self.view.frame.width-40, height: 50)
        Cartplist = cartobj.getData()
        fatchCartData()
    }
    
    func fatchCartData()
    {
        Cartplist = cartobj.getData()
        item_Id.removeAll()
        item_Qty.removeAll()
        item_Price.removeAll()
        Is_veg.removeAll()
        if Cartplist.count > 0
        {
            let dic = Cartplist[0] as! [String : Int]
            if dic["Res_id"] == Res_id
            {
                
                for i in 0...Cartplist.count-1
                {
                    let dic = Cartplist[i] as! [String : Int]
                    item_Id.append(dic["Item_id"]!)
                    item_Qty.append(dic["Item_qty"]!)
                    item_Price.append(dic["Item_price"]!)
                    Is_veg.append(dic["Is_veg"]!)
                }
                temp = true
                getTotalAmount()
            }
            
        }
        else
        {
            temp = true
        }
        tblitem.reloadData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        if Offer_details.isEmpty == true
        {
            Offer_details = OfferDataObj.getData()
        }
        fatchCartData()
    }
    
    @IBAction func btnpayment(_ sender: Any)
    {
        let stb = self.storyboard?.instantiateViewController(withIdentifier: "payfororder") as! payfororder
        stb.Grand_Total = Grand_total
        var itemidstr = ""
        var itemqrystr = ""
        for i in 0...item_Id.count - 1
        {
            itemidstr += String(item_Id[i])
            itemqrystr += String(item_Qty[i])
            if i < item_Id.count - 1{
                itemidstr += ","
                itemqrystr += ","
            }
        }
        stb.itemidstr = itemidstr
        stb.itemqtystr = itemqrystr
        self.navigationController?.pushViewController(stb, animated: true)
    }
    func numberOfSections(in tableView: UITableView) -> Int
    {
        return 3
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        if section == 0
        {
            return item_Id.count + 2
        }
        else
        {
            return 1
        }
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        if indexPath.section == 0
        {
            if indexPath.row == 0
            {
                let cell = tableView.dequeueReusableCell(withIdentifier: "itemtblcartcell1", for: indexPath) as! itemtblcartcell1
                let str = "http://localhost/project/Restaurant_image/"
                let finalStr = str.appending(Res_image)
                let url = URL(string: finalStr)
                do
                {
                    let imgData = try Data.init(contentsOf: url!)
                    cell.imgview.image = UIImage(data: imgData)
                    cell.imgview.clipsToBounds = true
                    cell.imgview.layer.cornerRadius = 5
                }
                catch{}
                cell.lblresname.text = Res_name
                return cell
            }
            else if indexPath.row > 0 && indexPath.row <= item_Id.count
            {
                let cell = tableView.dequeueReusableCell(withIdentifier: "itemtblcartcell2", for: indexPath) as! itemtblcartcell2
                let dic = Cartplist[indexPath.row-1] as! [String : Int]
                cell.lblitemprice.text = "₹" + String(dic["Item_price"]!)
                cell.btnadditem.tag = dic["Item_id"]!
                cell.btndeleteitem.tag = dic["Item_id"]!
                cell.lblitemcounter.tag = dic["Item_id"]!
                let totelamt = Int(dic["Item_qty"]!) * Int(dic["Item_price"]!)
                cell.lbltotalamt.text = "₹" + String(totelamt)
                var a:Bool = false
                if dic["Is_veg"] == 1 {
                   cell.vegicon.image = UIImage(named: "veg.jpg")
                }
                else {
                    cell.vegicon.image = UIImage(named: "nonveg.jpg")
                }
                if item_Id.count > 0 {
                    for i in 0...item_Id.count-1 {
                        if Int(dic["Item_id"]!) == item_Id[i] {
                            cell.lblitemcounter.text = String(item_Qty[i])
                            a = true
                            break
                        }
                    }
                }
                if a == false {
                    cell.lblitemcounter.text = "0"
                }
                for i in 0...itemdetails.count - 1 {
                    let dic1 = itemdetails[i]
                    if dic["Item_id"] == Int(dic1["Item_id"]!) {
                        cell.lblitemname.text = dic1["Item_name"]
                        break
                    }
                }
                return cell
            }
            else {
                let cell = tableView.dequeueReusableCell(withIdentifier: "itemtblcartcell3", for: indexPath) as! itemtblcartcell3
                 cell.lblgrandtotal.text = "₹" + String(Item_total)
                return cell
            }
        }
        else if indexPath.section == 1 {
            let cell = tableView.dequeueReusableCell(withIdentifier: "itemtblcartcell4", for: indexPath) as! itemtblcartcell4
            if Offer_details.isEmpty == false
            {
                cell.lbloffercode.text = Offer_details["Offer_code"]! + " - Applied "
                cell.imgview.image = UIImage(named: "tick")
                cell.btnremove.isHidden = false
                cell.lblofferamt.isHidden = false
                cell.lblofferamt.text = "-₹\(Offer_amt)"
            }
            else{
                cell.lbloffercode.text = "Apply Promo Code"
                cell.btnremove.isHidden = true
                cell.lblofferamt.isHidden = true
                cell.imgview.image = UIImage(named: "discount")
            }
            return cell
        }
        else {
            let cell = tableView.dequeueReusableCell(withIdentifier: "itemtblcartcell5", for: indexPath) as! itemtblcartcell5
            if Offer_details.isEmpty == false
            {
                cell.lbloffercode.text = Offer_details["Offer_code"]
                cell.lblofferamt.text = "-₹\(Offer_amt)"
                Grand_total = Item_total - Double(Offer_amt)
                cell.lbloffercode.isHidden = false
                cell.lblofferamt.isHidden = false
            }
            else{
                Grand_total = Item_total
                cell.lbloffercode.isHidden = true
                cell.lblofferamt.isHidden = true
            }
             cell.lblitemtotal.text = "₹" + String(Item_total)
            cell.lblgrandtotal.text = "₹" + String(Grand_total)
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        if indexPath.section == 1 && Offer_details.isEmpty == true
        {
            let stb = self.storyboard?.instantiateViewController(withIdentifier: "promocode")
            self.navigationController?.pushViewController(stb!, animated: true)
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.section == 0 {
            if indexPath.row == 0 {
                return 75.0
            }
            else if indexPath.row > 0 && indexPath.row <= item_Id.count {
                return 95.0
            }
            else {
                return 50.0
            }
        }
        else if indexPath.section == 1 {
            return 70.0
        }
        else {
            return 130.0
        }
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 10.0
    }
    
    
    @IBAction func btnremove(_ sender: UIButton)
    {
        OfferDataObj.deleteData()
        Offer_details = [:]
        fatchCartData()
    }
    
    @IBAction func btndeleteitem(_ sender: UIButton) {
        if item_Id.count > 0
        {
            for i in 0...item_Id.count - 1
            {
                if item_Id[i] == sender.tag
                {
                    item_Qty[i] = item_Qty[i] - 1
                    if item_Qty[i] == 0
                    {
                        cartobj.deleteData(itemid: item_Id[i])
                        item_Id.remove(at: i)
                        item_Qty.remove(at: i)
                        item_Price.remove(at: i)
                        break
                    }
                    else
                    {
                        let cartdic = ["Res_id":Res_id,"Item_id":item_Id[i],"Item_qty":item_Qty[i],"Item_price":item_Price[i],"Is_veg":Is_veg[i]]
                        cartobj.update(cartdata: cartdic)
                        break
                    }
                }
            }
        }
        if item_Id.count == 0
        {
            navigationController?.popViewController(animated: true)
        }
        getTotalAmount()
    }
    
    @IBAction func btnadditem(_ sender: UIButton)
    {
        if item_Id.count > 0
        {
            for i in 0...item_Id.count - 1
            {
                if item_Id[i] == sender.tag
                {
                    item_Qty[i] = item_Qty[i] + 1
                    let cartdic = ["Res_id":Res_id,"Item_id":item_Id[i],"Item_qty":item_Qty[i],"Item_price":item_Price[i],"Is_veg":Is_veg[i]]
                    cartobj.update(cartdata: cartdic)
                    getTotalAmount()
                    break
                }
            }
        }
        else
        {
        }
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat
    {
        return 10.0
    }
    
    func getTotalAmount()
    {
        Item_total = 0
        if item_Id.count > 0
        {
            for i in 0...item_Id.count - 1
            {
                let total = Double(item_Qty[i]) * Double(item_Price[i])
                Item_total = Item_total + total
                if Offer_details.isEmpty == false
                {
                    Offer_amt = Int(Item_total) * Int(Offer_details["Discount_of_per"]!)! / 100
                    if Offer_amt > Int(Offer_details["Max_discount"]!)!
                    {
                        Offer_amt = Int(Offer_details["Max_discount"]!)!
                    }
                }
                else {
                    Offer_amt = 0
                }
                
            }
            Cartplist = cartobj.getData()
            tblitem.reloadData()
        }
    }
}
