//
//  itemtblcartcell1.swift
//  ProjectDemo
//
//  Created by MAC2 on 15/02/19.
//  Copyright © 2019 TOPS. All rights reserved.
//

import UIKit

class itemtblcartcell1: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        
    }
    @IBOutlet weak var imgview: UIImageView!
    @IBOutlet weak var lblresname: UILabel!
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
