
//
//  item.swift
//  ProjectDemo
//
//  Created by MAC2 on 22/01/19.
//  Copyright © 2019 TOPS. All rights reserved.
//

import UIKit

class item: UIViewController,UITableViewDataSource,UITableViewDelegate
{
    var Res_id:Int = 0
    var Res_rating:Float = 0.0
    var Res_image:String = ""
    var Res_name:String = ""
    var itemdetails:[[String:String]] = [[:]]
    var item_Id:[Int] = []
    var item_Qty:[Int] = []
    var item_Price:[Int] = []
    var is_veg:[Int] = []
    var time = Timer()
    var sec = 0
    var hidecart:Bool = true
    var subview = UIView()
    var lblitemQty = UILabel()
    var lblamt = UILabel()
    var cartobj = CartData()
    var temp:Bool = false
    var Cartplist:[Any] = []
    var changeRes:Bool = false
    var addcart:Bool = true
    var grand_total:Double = 0.0
    var Offer_details:[String : String] = [:]
    var OfferDataObj = OfferData()
    
    @IBOutlet weak var resImageview: UIImageView!
    @IBOutlet weak var itemtblview: UITableView!

    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        itemtblview.frame = CGRect(x: 0, y: 179, width: self.view.frame.width, height: self.view.frame.height-179)
        cart()
        fatchCartData()
        navigationController?.navigationBar.layer.opacity=0.5
        navigationController?.navigationBar.layer.masksToBounds = true
        navigationController?.navigationBar.layer.shadowOpacity = 0.5
        navigationController?.navigationBar.isHidden = false
        tabBarController?.tabBar.isHidden = true
        fatchItemData()
        let str = "http://localhost/project/Restaurant_image/"
        let finalStr = str.appending(Res_image)
        let url = URL(string: finalStr)
        do
        {
            let imgData = try Data.init(contentsOf: url!)
            resImageview.image = UIImage(data: imgData)
        }
        catch
        {
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        fatchCartData()
        OfferDataObj.deleteData()
    }
    
    func fatchCartData()
    {
        Cartplist = cartobj.getData()
        item_Id.removeAll()
        item_Qty.removeAll()
        item_Price.removeAll()
        is_veg.removeAll()
        if Cartplist.count > 0
        {
            let dic = Cartplist[0] as! [String : Int]
            if dic["Res_id"] == Res_id
            {
               
                for i in 0...Cartplist.count-1
                {
                    let dic = Cartplist[i] as! [String : Int]
                    item_Id.append(dic["Item_id"]!)
                    item_Qty.append(dic["Item_qty"]!)
                    item_Price.append(dic["Item_price"]!)
                    is_veg.append(dic["Is_veg"]!)
                }
                temp = true
                getTotalAmount()
                showCart()
            }
            else
            {
                changeRes = true
            }
        }
        else{
            temp = true
            hideCart()
        }
        itemtblview.reloadData()
    }
    
    func deleteCartData()
    {
        Cartplist = cartobj.getData()
        if Cartplist.count > 0 {
            let dic = Cartplist[0] as! [String : Int]
            if dic["Res_id"] != Res_id
            {
                cartobj.DeleteCart()
                temp = true
            }
            else
            {
            }
        }
    }
    
    func fatchItemData()
    {
        let url = URL(string: "http://localhost/project/fatchItemDetails.php?Res_id=\(Res_id)")
        let request = URLRequest(url: url!)
        let session = URLSession.shared
        let datatask = session.dataTask(with: request)
        { (data, rest, err) in
            DispatchQueue.main.async
                {
                do
                {
                    try self.itemdetails = JSONSerialization.jsonObject(with: data!, options: []) as! [[String:String]]
                    if self.itemdetails.count > 0
                    {
                        self.itemtblview.reloadData()
                    }
                }catch
                {
                }
            }
        }
        datatask.resume()
    }
    
    func numberOfSections(in tableView: UITableView) -> Int
    {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return itemdetails.count + 1
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        if indexPath.row == 0
        {
            let cell = tableView.dequeueReusableCell(withIdentifier: "rescell", for: indexPath) as! rescell
            cell.lblRating.text = String(Res_rating)
            cell.lblRating.clipsToBounds = true
            cell.lblRating.layer.cornerRadius = 5
            cell.lblresname.text = Res_name
            return cell
        }
        else
        {
            let dic = itemdetails[indexPath.row-1]
            let cell = tableView.dequeueReusableCell(withIdentifier: "itemcell", for: indexPath) as! itemcell
            cell.lblitemname.text = dic["Item_name"]
            let str = "http://localhost/project/Item_image/"
            if dic.isEmpty == false
            {
                cell.lblPrice.text = "₹" + dic["Item_price"]!
                cell.btndeleteitem.tag = Int(dic["Item_id"]!)!
                cell.btnadditem.tag = Int(dic["Item_id"]!)!
                cell.lblitemcounter.tag = Int(dic["Item_id"]!)!
                if temp == true
                {
                    var a:Bool = false
                    if item_Id.count > 0
                    {
                        for i in 0...item_Id.count-1
                        {
                            if Int(dic["Item_id"]!) == item_Id[i]
                            {
                                cell.lblitemcounter.text = String(item_Qty[i])
                                a = true
                                break
                            }
                        }
                    }
                    if a == false
                    {
                        cell.lblitemcounter.text = "0"
                    }
                }
                let finalStr = str.appending(dic["Item_image"]!)
                let url = URL(string: finalStr)
                do
                {
                    let imgData = try Data.init(contentsOf: url!)
                    cell.itemimageview.image = UIImage(data: imgData)
                    cell.itemimageview.clipsToBounds = true
                    cell.itemimageview.layer.cornerRadius = 5
                }
                catch
                {
                }
            }
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        if indexPath.row == 0
        {
            return 100.0
        }
        else
        {
            return 110.0
        }
    }
    
    @IBAction func btndeleteitem(_ sender: UIButton) {
        if item_Id.count > 0
        {
            for i in 0...item_Id.count - 1
            {
                if item_Id[i] == sender.tag
                {
                    item_Qty[i] = item_Qty[i] - 1
                    if item_Qty[i] == 0
                    {
                        cartobj.deleteData(itemid: item_Id[i])
                        item_Id.remove(at: i)
                        item_Qty.remove(at: i)
                        item_Price.remove(at: i)
                        is_veg.remove(at: i)
                        break
                    }
                    else
                    {
                        let cartdic = ["Res_id":Res_id,"Item_id":item_Id[i],"Item_qty":item_Qty[i],"Item_price":item_Price[i],"Is_veg":is_veg[i]]
                        cartobj.update(cartdata: cartdic)
                        break
                    }
                }
            }
        }
        getTotalAmount()
        itemtblview.reloadData()
    }
    
    @IBAction func btnadditem(_ sender: UIButton) {
        deleteCartData()
        if item_Id.count > 0
        {
            var temp:Bool = false
            for i in 0...item_Id.count - 1
            {
                if item_Id[i] == sender.tag
                {
                    temp = true
                    item_Qty[i] = item_Qty[i] + 1
                    let cartdic = ["Res_id":Res_id,"Item_id":item_Id[i],"Item_qty":item_Qty[i],"Item_price":item_Price[i],"Is_veg":is_veg[i]]
                    cartobj.update(cartdata: cartdic)
                    getTotalAmount()
                    itemtblview.reloadData()
                    break
                }
            }
            if temp == false
            {
                item_Id.append(sender.tag)
                item_Qty.append(1)
                is_veg.append(checkIsVeg(Item_id: sender.tag))
                getprice(item_id: sender.tag)
            }
        }
        else
        {
            item_Id.append(sender.tag)
            item_Qty.append(1)
            is_veg.append(checkIsVeg(Item_id: sender.tag))
            getprice(item_id: sender.tag)
        }
    }
    
    func checkIsVeg(Item_id:Int) -> Int {
        for i in 0...itemdetails.count - 1 {
            let dic = itemdetails[i]
            if Int(dic["Item_id"]!) == Item_id {
                return Int(dic["Is_veg"]!)!
            }
        }
        return 0
    }
    
    func getprice(item_id:Int)
    {
            let url = URL(string: "http://localhost/project/Fatch_Single_Item.php?Item_id=\(item_id)")
            let request = URLRequest(url: url!)
            let session = URLSession.shared
            let datatask = session.dataTask(with: request)
            { (data, rest, err) in
                DispatchQueue.main.async
                {
                    do
                    {
                        let singleitem = try JSONSerialization.jsonObject(with: data!, options: []) as! [[String:String]]
                        if singleitem.count > 0
                        {
                            let dic = singleitem[0]
                            let price = Int(dic["Item_price"]!)
                            self.item_Price.append(price!)
                            let cartdic = ["Res_id":self.Res_id,"Item_id":self.item_Id[self.item_Id.count-1],"Item_qty":self.item_Qty[self.item_Qty.count-1],"Item_price":self.item_Price[self.item_Price.count-1],"Is_veg":self.is_veg[self.item_Id.count-1]]
                            self.cartobj.insertData(cartdata: cartdic)
                            self.getTotalAmount()
                            self.itemtblview.reloadData()
                        }
                    }
                    catch
                    {
                    }
                }
            }
            datatask.resume()
    }
    
    func getTotalAmount()
    {
        grand_total = 0
        var Total_Qty:Int = 0
        if item_Id.count > 0
        {
            for i in 0...item_Id.count - 1
            {
                let total = item_Qty[i] * item_Price[i]
                grand_total = grand_total + Double(total)
                Total_Qty = Total_Qty + item_Qty[i]
            }
            if Total_Qty == 1
            {
                lblitemQty.text = String(Total_Qty) + " Item"
            }
            else
            {
                lblitemQty.text = String(Total_Qty) + " Items"
            }
            lblamt.text = "₹" + String(Int(grand_total))
            if hidecart == true
            {
                showCart()
            }
        }
        else
        {
            hideCart()
        }
    }
    
    func cart()
    {
        subview.frame = CGRect(x: 0, y: self.view.frame.height+10, width: self.view.frame.width, height: 50)
        lblitemQty = UILabel(frame: CGRect(x: 10, y: 5, width: 60, height: 10))
        lblamt = UILabel(frame: CGRect(x: 10, y: 20, width: 80, height: 20))
        let lblcart = UILabel(frame: CGRect(x: self.view.frame.width-120, y: 10, width: 100, height: 30))
        let tap = UITapGestureRecognizer(target: self, action: #selector(self.test1))
        tap.numberOfTapsRequired = 1
        subview.isUserInteractionEnabled = true
        lblcart.textColor = UIColor.white
        lblamt.textColor = UIColor.white
        lblitemQty.textColor = UIColor.white
        lblitemQty.font = UIFont.systemFont(ofSize: 13.0)
        lblamt.font = UIFont.systemFont(ofSize: 17.0)
        lblcart.font = UIFont.systemFont(ofSize: 22.0)
        lblcart.text = "View Cart"
        subview.backgroundColor = UIColor.red
        subview.addSubview(lblitemQty)
        subview.addSubview(lblamt)
        subview.addGestureRecognizer(tap)
        subview.addSubview(lblcart)
        self.view.addSubview(subview)
    }
    
    @objc func showCart()
    {
        sec = 0
        time = Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(self.test(_:)), userInfo: nil, repeats: true)
        UIView.beginAnimations(nil, context: nil)
        UIView.setAnimationDuration(0.5)
        UIView.setAnimationDelegate(self)
        subview.frame = CGRect(x: 0, y: self.view.frame.height-50, width: self.view.frame.width, height: 50)
        UIView.commitAnimations()
        hidecart = false
    }
    
    @objc func hideCart()
    {
        sec = 0
        time = Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(self.test(_:)), userInfo: nil, repeats: true)
        UIView.beginAnimations(nil, context: nil)
        UIView.setAnimationDuration(0.5)
        UIView.setAnimationDelegate(self)
        subview.frame = CGRect(x: 0, y: self.view.frame.height+10, width: self.view.frame.width, height: 50)
        UIView.commitAnimations()
        hidecart = true
    }
    
    @objc func test(_ sender:Timer)
    {
        if sec < 5
        {
               sec = sec + 1
        }
        else
        {
            time.invalidate()
        }
    }
    func test1(_ sender:UITapGestureRecognizer)
    {
        let stb = self.storyboard?.instantiateViewController(withIdentifier: "itemcart") as! itemcart
        stb.Res_id = Res_id
        stb.Res_name = Res_name
        stb.Res_image = Res_image
        stb.itemdetails = itemdetails
        stb.Item_total = grand_total
        stb.Offer_details = Offer_details
        navigationController?.pushViewController(stb, animated: true)
    }
}
