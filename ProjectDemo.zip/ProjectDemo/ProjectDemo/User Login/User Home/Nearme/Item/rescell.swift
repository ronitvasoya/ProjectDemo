//
//  rescell.swift
//  ProjectDemo
//
//  Created by MAC2 on 22/01/19.
//  Copyright © 2019 TOPS. All rights reserved.
//

import UIKit

class rescell: UITableViewCell {

    @IBOutlet weak var lblRating: UILabel!
    @IBOutlet weak var lblcategory: UILabel!
    @IBOutlet weak var lblresname: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
