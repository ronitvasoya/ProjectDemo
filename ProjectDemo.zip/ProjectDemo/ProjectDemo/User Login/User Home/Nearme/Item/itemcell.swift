//
//  itemcell.swift
//  ProjectDemo
//
//  Created by MAC2 on 22/01/19.
//  Copyright © 2019 TOPS. All rights reserved.
//

import UIKit

class itemcell: UITableViewCell {

    @IBOutlet weak var itemimageview: UIImageView!
    @IBOutlet weak var lblPrice: UILabel!
    @IBOutlet weak var lblitemname: UILabel!
    @IBOutlet weak var lblitemcounter: UILabel!
    @IBOutlet weak var btnadditem: UIButton!
    @IBOutlet weak var btndeleteitem: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }

}
