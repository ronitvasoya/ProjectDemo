//
//  CartData.swift
//  ProjectDemo
//
//  Created by Ronit Vasoya on 14/02/19.
//  Copyright © 2019 TOPS. All rights reserved.
//

import UIKit

class CartData: NSObject {

    var arrdic:[Any] = []
    
    func getData() -> [Any] {
        let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let strpath = path[0]
        let fullpath = strpath.appending("/cartdata.plist")
        print(fullpath)
        let fmg = FileManager()
        arrdic = []
        if fmg.fileExists(atPath: fullpath)
        {
            let dic = NSDictionary(contentsOfFile: fullpath)
            arrdic = dic!["CartData"] as! [Any]
        }
        return arrdic
    }
    
    func insertData(cartdata : [String : Int]) {
        let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let strpath = path[0]
        let fullpath = strpath.appending("/cartdata.plist")
        arrdic = getData()
        arrdic.append(cartdata)
        let dic = ["CartData":arrdic]
        let finaldic = NSDictionary(dictionary: dic)
        finaldic.write(toFile: fullpath, atomically: true)
    }
    
    func update(cartdata : [String : Int])  {
        arrdic = getData()
        for i in 0...arrdic.count - 1
        {
            let dic = arrdic[i] as! [String : Int]
            if dic["Item_id"] == cartdata["Item_id"]
            {
                arrdic[i] = cartdata
                break
            }
        }
        let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let strpath = path[0]
        let fullpath = strpath.appending("/cartdata.plist")
        let dic = ["CartData":arrdic]
        let finaldic = NSDictionary(dictionary: dic)
        finaldic.write(toFile: fullpath, atomically: true)
    }
    
    func DeleteCart() {
        arrdic = []
        let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let strpath = path[0]
        let fullpath = strpath.appending("/cartdata.plist")
        let dic = ["CartData":arrdic]
        let finaldic = NSDictionary(dictionary: dic)
        finaldic.write(toFile: fullpath, atomically: true)
    }
    
    func deleteData(itemid : Int) {
        arrdic = getData()
        var finalarr:[Any] = []
        for i in 0...arrdic.count - 1
        {
            let dic = arrdic[i] as! [String : Int]
            if dic["Item_id"] != itemid
            {
                finalarr.append(arrdic[i])
            }
        }
        let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let strpath = path[0]
        let fullpath = strpath.appending("/cartdata.plist")
        let dic = ["CartData":finalarr]
        let finaldic = NSDictionary(dictionary: dic)
        finaldic.write(toFile: fullpath, atomically: true)
    }
}
