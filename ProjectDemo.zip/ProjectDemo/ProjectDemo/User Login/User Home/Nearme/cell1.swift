//
//  cell1.swift
//  ProjectDemo
//
//  Created by MAC2 on 11/01/19.
//  Copyright © 2019 TOPS. All rights reserved.
//

import UIKit

class cell1: UITableViewCell {

    @IBOutlet weak var imgview: UIImageView!
    @IBOutlet weak var txtviewresname: UITextView!
    @IBOutlet weak var lblResCategory: UILabel!
    @IBOutlet weak var lblLiveTraking: UILabel!
    @IBOutlet weak var lblReating: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
