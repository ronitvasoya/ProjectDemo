import UIKit
import Reachability

class nearme: UIViewController,UITableViewDataSource,UITableViewDelegate,UICollectionViewDelegate,UICollectionViewDataSource {
    
    @IBOutlet weak var tblviewRes: UITableView!
    @IBOutlet weak var OfferCollView: UICollectionView!
    
    var resdetails:[[String:String]] = [[:]]
    var offerdetails:[[String:String]] = [[:]]
    var OfferDataObj = OfferData()
    var lblAddress = UILabel()
    var lbllocaliti = UILabel()
    var Address:[String:String] = [:]
    var AddressObj = AddressPlist()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        fatchResData()
        fetchofferimage()
        SetPassword()
        addressBar()
        let reachability = Reachability()!
        
        //declare this inside of viewWillAppear
        
        NotificationCenter.default.addObserver(self, selector: #selector(reachabilityChanged(note:)), name: .reachabilityChanged, object: reachability)
        do{
            try reachability.startNotifier()
        }catch{
            print("could not start reachability notifier")
        }
    }
    
    @objc func reachabilityChanged(note: Notification) {
        
        let reachability = note.object as! Reachability
        
        switch reachability.connection {
        case .wifi:
            print("Reachable via WiFi")
        case .cellular:
            print("Reachable via Cellular")
        case .none:
            print("Network not reachable")
        default: print("ronit")
                break
        }
    }
    
    func SetPassword()  {
        let profile = loginObj.getData()
        if profile["Cust_password"] == ""
        {
            let alert = UIAlertController(title: "Alert", message: "Set Your Password for Food Vector", preferredStyle: .alert);
            let ok = UIAlertAction(title: "Yes", style: .default)
            {
                ACTION in
                let stb = self.storyboard?.instantiateViewController(withIdentifier: "SetPassword")
                self.navigationController?.pushViewController(stb!, animated: true)
            }
            let trylater = UIAlertAction(title: "Try Later", style: .default)
            {
                ACTION in
            }
            alert.addAction(ok);
            alert.addAction(trylater);
            self.present(alert, animated: true, completion: nil);
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        navigationController?.navigationBar.isHidden = true
        tabBarController?.tabBar.isHidden = false
        OfferDataObj.deleteData()
        Address = AddressObj.getData()
        if Address.isEmpty == false
        {
            lblAddress.text = Address["Address"]
        }
        else {
            lblAddress.text = "Set Your Location"
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
       self.view.endEditing(true)
    }
    
    func fatchResData() {
        let url = URL(string: "http://localhost/project/fatchResDetails.php")
        let request = URLRequest(url: url!)
        let session = URLSession.shared
        let datatask = session.dataTask(with: request) { (data, rest, err) in

                DispatchQueue.main.async {
                    do{
                        try self.resdetails = JSONSerialization.jsonObject(with: data!, options: []) as! [[String:String]]
                        if self.resdetails.count > 0{
                            self.tblviewRes.reloadData()
                        }
                    }catch{
                        
                    }
            }
        }
        datatask.resume()
    }

    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return resdetails.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.row != 4
        {
            var dic = resdetails[indexPath.row]
            let cell = tableView.dequeueReusableCell(withIdentifier: "cell1", for: indexPath) as! cell1
            cell.lblReating.layer.cornerRadius = 5
            cell.lblReating.clipsToBounds = true
            cell.lblReating.text = dic["Rating"]
            
            cell.lblReating.backgroundColor = UIColor.orange
            let str = "http://localhost/project/Restaurant_image/"
            if dic.isEmpty == false
            {
                let finalStr = str.appending(dic["Res_image"]!)
                let url = URL(string: finalStr)
                do{
                    let imgData = try Data.init(contentsOf: url!)
                    cell.imgview.image = UIImage(data: imgData)
                    cell.imgview.clipsToBounds = true
                    cell.imgview.layer.cornerRadius = 5
                }catch{
                    
                }
            }
            cell.lblresname.text = dic["Res_name"]
            if dic["Is_active"] == "1"
            {
                cell.lblLiveTraking.text = "Live Traking"
            }
            else
            {
                cell.lblLiveTraking.text = "No Live Traking"
            }
            return cell
        }
        else
        {
            let Colcell = tableView.dequeueReusableCell(withIdentifier: "cell2", for: indexPath) as! cell2
            Colcell.ColviewTranding.reloadData()
            return Colcell
        }
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.row == 3
        {
            return 200.0
        }
        else
        {
            return 117.0
        }
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        var dic = resdetails[indexPath.row]
        let stb = self.storyboard?.instantiateViewController(withIdentifier: "item") as! item
        
        stb.Res_id = Int(dic["Res_id"]!)!
        stb.Res_rating = Float(dic["Rating"]!)!
        stb.Res_image = dic["Res_image"]!
        stb.Res_name = dic["Res_name"]!
        self.navigationController?.pushViewController(stb, animated: true)
        
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 10.0
    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return offerdetails.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        if collectionView.tag == 0
        {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "colcell1", for: indexPath) as! custcell1
            cell.imgview.clipsToBounds = true
            cell.imgview.layer.cornerRadius = 5
            let dic = offerdetails[indexPath.row]
            let str = "http://localhost/project/"
            if dic.isEmpty == false
            {
                let finalStr = str.appending(dic["Offer_image"]!)
                let url = URL(string: finalStr)
                do{
                    let imgData = try Data.init(contentsOf: url!)
                    cell.imgview.image = UIImage(data: imgData)
                }catch{
                    
                }
            }
            return cell
        }
        else
        {
        //collectionView.register(custcell2, forCellWithReuseIdentifier: "colcell2")
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "colcell2", for: indexPath) as! custcell2;
            cell.imgview.image = UIImage(named: "back1.jpg")
        cell.lblResName.text = "Domino's"
        return cell
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let dic = offerdetails[indexPath.row]
        for i in 0...resdetails.count - 1
        {
            let resdic = resdetails[i]
            if resdic["Res_id"] == dic["Res_id"]
            {
                let stb = self.storyboard?.instantiateViewController(withIdentifier: "item") as! item
                
                stb.Res_id = Int(resdic["Res_id"]!)!
                stb.Res_rating = Float(resdic["Rating"]!)!
                stb.Res_image = resdic["Res_image"]!
                stb.Res_name = resdic["Res_name"]!
                stb.Offer_details = dic
                self.navigationController?.pushViewController(stb, animated: true)
                break
            }
        }
    }
    
    func fetchofferimage()
    {
        let url = URL(string: "http://localhost/project/Fetch_Offer_Details.php")
        let request = URLRequest(url: url!)
        let session = URLSession.shared
        let datatask = session.dataTask(with: request) { (data, rest, err) in
            
            DispatchQueue.main.async {
                do{
                    try self.offerdetails = JSONSerialization.jsonObject(with: data!, options: []) as! [[String:String]]
                    
                    if self.offerdetails.count > 0{
                        self.OfferCollView.reloadData()
                    }
                }catch{
                    
                }
            }
        }
        datatask.resume()
    }
    
    func addressBar()
    {
        let subview = UIView(frame: CGRect(x: 0, y: 20, width: self.view.frame.width, height: 50))
        let border = CALayer()
        let width = CGFloat(2.0)
        border.borderColor = UIColor.darkGray.cgColor
        border.frame = CGRect(x: 0, y: subview.frame.height-width, width: subview.frame.width, height: subview.frame.height)
        border.borderWidth = width
        subview.layer.addSublayer(border)
        subview.layer.masksToBounds = true
        lbllocaliti = UILabel(frame: CGRect(x: 20, y: 5, width: 75, height: 20))
        lbllocaliti.text = "Home"
        lblAddress = UILabel(frame: CGRect(x: 20, y: 25, width: self.view.frame.width-40, height: 20))
        lblAddress.text = ""
        lblAddress.font = UIFont.systemFont(ofSize: 15.0)
        let tap = UITapGestureRecognizer(target: self, action: #selector(self.test1))
        tap.numberOfTapsRequired = 1
        subview.isUserInteractionEnabled = true
        subview.addSubview(lblAddress)
        subview.addSubview(lbllocaliti)
        subview.addGestureRecognizer(tap)
        self.view.addSubview(subview)
    }
    
    func test1(_ sender:UITapGestureRecognizer)
    {
       let stb = self.storyboard?.instantiateViewController(withIdentifier: "location")
        navigationController?.pushViewController(stb!, animated: false)
    }
}
