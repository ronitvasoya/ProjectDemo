//
//  OfferData.swift
//  ProjectDemo
//
//  Created by Ronit Vasoya on 21/02/19.
//  Copyright © 2019 TOPS. All rights reserved.
//

import UIKit

class OfferData: NSObject {
    
    var Offer_Data:[String : String] = [:]
    
    func getData() -> [String : String] {
        let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let strpath = path[0]
        let fullpath = strpath.appending("/offerdata.plist")
        print(fullpath)
        let fmg = FileManager()
        Offer_Data = [:]
        if fmg.fileExists(atPath: fullpath)
        {
            Offer_Data = NSDictionary(contentsOfFile: fullpath) as! [String : String]
        }
        return Offer_Data
    }
    
    func insertData(offerdata : [String : String]) {
        let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let strpath = path[0]
        let fullpath = strpath.appending("/offerdata.plist")
        let finaldic = NSDictionary(dictionary: offerdata)
        finaldic.write(toFile: fullpath, atomically: true)
    }
    
    func deleteData() {
        let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let strpath = path[0]
        let fullpath = strpath.appending("/offerdata.plist")
        Offer_Data = [:]
        let finaldic = NSDictionary(dictionary: Offer_Data)
        finaldic.write(toFile: fullpath, atomically: true)
    }
}
