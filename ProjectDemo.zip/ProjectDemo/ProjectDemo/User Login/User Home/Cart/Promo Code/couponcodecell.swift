//
//  couponcodecell.swift
//  ProjectDemo
//
//  Created by Ronit Vasoya on 21/02/19.
//  Copyright © 2019 TOPS. All rights reserved.
//

import UIKit

class couponcodecell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    @IBOutlet weak var lblcodedescription: UILabel!
    @IBOutlet weak var btnapply: UIButton!
    @IBOutlet weak var lblcode: UILabel!
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
