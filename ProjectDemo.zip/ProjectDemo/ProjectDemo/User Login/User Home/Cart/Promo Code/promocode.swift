//
//  promocode.swift
//  ProjectDemo
//
//  Created by Ronit Vasoya on 21/02/19.
//  Copyright © 2019 TOPS. All rights reserved.
//

import UIKit

class promocode: UIViewController,UITableViewDelegate,UITableViewDataSource {

    var offerdetails:[[String:String]] = [[:]]
    var OfferDataObj = OfferData()
    
    @IBOutlet weak var tblview: UITableView!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        fetchapplicationoffer()
        navigationController?.navigationBar.isHidden = false
        tabBarController?.tabBar.isHidden = true
    }
    

    @IBAction func btnapply(_ sender: UIButton)
    {
        for i in 0...offerdetails.count - 1
        {
            let dic = offerdetails[i]
            if Int(dic["Offer_id"]!) == sender.tag
            {
                OfferDataObj.insertData(offerdata: dic)
                self.navigationController?.popViewController(animated: true)
                
            }
        }
    }
    
    func numberOfSections(in tableView: UITableView) -> Int
    {
        return 1
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return offerdetails.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "couponcodecell", for: indexPath) as! couponcodecell
        let dic = offerdetails[indexPath.row]
        if dic.isEmpty == false
        {
            cell.lblcode.text = dic["Offer_code"]
            cell.lblcodedescription.text = dic["Offer_description"]
            cell.btnapply.tag = Int(dic["Offer_id"]!)!
            cell.lblcode.clipsToBounds = true
            cell.lblcode.layer.cornerRadius = 5
        }
        return cell
    }
    
    func fetchapplicationoffer()
    {
        let url = URL(string: "http://localhost/project/Fetch_Application_Offer_Details.php")
        let request = URLRequest(url: url!)
        let session = URLSession.shared
        let datatask = session.dataTask(with: request) { (data, rest, err) in
            
            DispatchQueue.main.async {
                do{
                    try self.offerdetails = JSONSerialization.jsonObject(with: data!, options: []) as! [[String:String]]
                    
                    if self.offerdetails.count > 0{
                        print(self.offerdetails)
                        self.tblview.reloadData()
                    }
                }catch{
                    
                }
            }
        }
        datatask.resume()
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return 100.0
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String?
    {
        return "Available Coupons"
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let v1 = UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.size.width, height: 50))
        let lbl = UILabel(frame: CGRect(x: 10, y: 0, width:v1.frame.size.width, height: 50))
        lbl.text = "Available Coupons"
        lbl.font = UIFont.systemFont(ofSize: 25.0)
        v1.addSubview(lbl)
        return v1
    }
    
}

