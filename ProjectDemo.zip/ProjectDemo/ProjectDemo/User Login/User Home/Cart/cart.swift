//
//  cart.swift
//  ProjectDemo
//
//  Created by MAC2 on 09/01/19.
//  Copyright © 2019 TOPS. All rights reserved.
//

import UIKit
import SwiftyButton


class cart: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    var Cartplist:[Any] = []
    var item_Id:[Int] = []
    var item_Qty:[Int] = []
    var item_Price:[Int] = []
    var is_Veg:[Int] = []
    var cartobj = CartData()
    var Res_id:Int = 0
    var Res_image:String = ""
    var Res_name:String = ""
    var itemdetails:[[String:String]] = [[:]]
    var Grand_Total:Double = 0.0
    var Item_total:Double = 0.0
    var temp:Bool = false
    var subview = UIView()
    var offerdetails:[String:String] = [:]
    var Offer_amt:Int = 0
    var OfferDataObj = OfferData()
    
    @IBOutlet weak var tblview: UITableView!
    @IBOutlet weak var btnpayment: FlatButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        btnpayment.frame = CGRect(x: 20, y: 560 , width: self.view.frame.width-40, height: 50)
        btnpayment.color = .red
        btnpayment.cornerRadius  = 5
        navigationController?.navigationBar.isHidden = true
        fatchCartData()
        createSubView()
     }
    @IBAction func btnpayment(_ sender: Any)
    {
        let stb = self.storyboard?.instantiateViewController(withIdentifier: "payfororder") as! payfororder
        stb.Grand_Total = Grand_Total
        var itemidstr = ""
        var itemqrystr = ""
        for i in 0...item_Id.count - 1
        {
            itemidstr += String(item_Id[i])
            itemqrystr += String(item_Qty[i])
            if i < item_Id.count - 1{
                itemidstr += ","
                itemqrystr += ","
            }
        }
        stb.itemidstr = itemidstr
        stb.itemqtystr = itemqrystr
        stb.Res_id = Res_id
        self.navigationController?.pushViewController(stb, animated: true)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        navigationController?.navigationBar.isHidden = true
        tabBarController?.tabBar.isHidden = false
        offerdetails = OfferDataObj.getData()
        print(offerdetails)
        fatchCartData()
    }
    
    func fatchResData()
    {
        let url = URL(string: "http://localhost/project/fatchSingleRes.php?Res_id=\(Res_id)")
        let request = URLRequest(url: url!)
        let session = URLSession.shared
        let datatask = session.dataTask(with: request)
        { (data, rest, err) in
            DispatchQueue.main.async
                {
                    do
                    {
                        let resdetails = try JSONSerialization.jsonObject(with: data!, options: []) as! [[String:String]]
                        if resdetails.count > 0
                        {
                            let dic = resdetails[0]
                            self.Res_name = dic["Res_name"]!
                            self.Res_image = dic["Res_image"]!
                            self.tblview.reloadData()
                        }
                    }catch
                    {
                    }
            }
        }
        datatask.resume()
    }
    
    func fatchItemData()
    {
        let url = URL(string: "http://localhost/project/fatchItemDetails.php?Res_id=\(Res_id)")
        let request = URLRequest(url: url!)
        let session = URLSession.shared
        let datatask = session.dataTask(with: request)
        { (data, rest, err) in
            DispatchQueue.main.async
                {
                    do
                    {
                        try self.itemdetails = JSONSerialization.jsonObject(with: data!, options: []) as! [[String:String]]
                        if self.itemdetails.count > 0
                        {
                            self.tblview.reloadData()
                        }
                    }catch
                    {
                    }
            }
        }
        datatask.resume()
    }
    
    func fatchCartData()
    {
        Cartplist = cartobj.getData()
        item_Id.removeAll()
        item_Qty.removeAll()
        item_Price.removeAll()
        is_Veg.removeAll()
        if Cartplist.count > 0
        {
            let dic = Cartplist[0] as! [String : Int]
            Res_id = dic["Res_id"]!
            for i in 0...Cartplist.count-1
            {
                let dic = Cartplist[i] as! [String : Int]
                item_Id.append(dic["Item_id"]!)
                item_Qty.append(dic["Item_qty"]!)
                item_Price.append(dic["Item_price"]!)
                is_Veg.append(dic["Is_veg"]!)
            }
            temp = true
            getTotalAmount()
            fatchResData()
            fatchItemData()
            subview.isHidden = true
        }
        else
        {
            subview.isHidden = false
        }
       
    }

    func numberOfSections(in tableView: UITableView) -> Int
    {
        return 3
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        if section == 0
        {
            return item_Id.count + 2
        }
        else
        {
            return 1
        }
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        if indexPath.section == 0
        {
            if indexPath.row == 0
            {
                let cell = tableView.dequeueReusableCell(withIdentifier: "tblcartcell1", for: indexPath) as! tblcartcell1
                let str = "http://localhost/project/Restaurant_image/"
                let finalStr = str.appending(Res_image)
                let url = URL(string: finalStr)
                do
                {
                    let imgData = try Data.init(contentsOf: url!)
                    cell.imgview.image = UIImage(data: imgData)
                    cell.imgview.clipsToBounds = true
                    cell.imgview.layer.cornerRadius = 5
                }
                catch{}
                cell.lblresname.text = Res_name
                return cell
            }
            else if indexPath.row > 0 && indexPath.row <= item_Id.count && item_Id.count > 0
            {
                let cell = tableView.dequeueReusableCell(withIdentifier: "tblcartcell2", for: indexPath) as! tblcartcell2
                let dic = Cartplist[indexPath.row-1] as! [String : Int]
                cell.lblitemprice.text = "₹" + String(dic["Item_price"]!)
                cell.btnadditem.tag = dic["Item_id"]!
                cell.btndeleteitem.tag = dic["Item_id"]!
                cell.lblitemcounter.tag = dic["Item_id"]!
                let totelamt = Int(dic["Item_qty"]!) * Int(dic["Item_price"]!)
                cell.lbltotalamt.text = "₹" + String(totelamt)
                var a:Bool = false
                if dic["Is_veg"] == 1 {
                    cell.vegicon.image = UIImage(named: "veg.jpg")
                }
                else {
                    cell.vegicon.image = UIImage(named: "nonveg.jpg")
                }
                if item_Id.count > 0
                {
                    for i in 0...item_Id.count-1
                    {
                        if Int(dic["Item_id"]!) == item_Id[i]
                        {
                            cell.lblitemcounter.text = String(item_Qty[i])
                            a = true
                            break
                        }
                    }
                }
                if a == false
                {
                    cell.lblitemcounter.text = "0"
                }
                if itemdetails.count > 0
                {
                    for i in 0...itemdetails.count - 1
                    {
                        let dic1 = itemdetails[i]
                        if dic1.isEmpty == false
                        {
                            if dic["Item_id"] == Int(dic1["Item_id"]!)
                            {
                                cell.lblitemname.text = dic1["Item_name"]
                                break
                            }
                        }
                    }
                }
                return cell
            }
            else
            {
                let cell = tableView.dequeueReusableCell(withIdentifier: "tblcartcell3", for: indexPath) as! tblcartcell3
                cell.lblgrandtotal.text = "₹" + String(Item_total)
                return cell
            }
        }
        else if indexPath.section == 1
        {
            let cell = tableView.dequeueReusableCell(withIdentifier: "tblcartcell4", for: indexPath) as! tblcartcell4
            if offerdetails.isEmpty == false
            {
                cell.offercode.text = offerdetails["Offer_code"]! + " - Applied "
                cell.imgview.image = UIImage(named: "tick")
                cell.btnremove.isHidden = false
                cell.lblofferamt.isHidden = false
                cell.lblofferamt.text = "-₹\(Offer_amt)"
            }
            else{
                cell.offercode.text = "Apply Promo Code"
                cell.btnremove.isHidden = true
                cell.lblofferamt.isHidden = true
                cell.imgview.image = UIImage(named: "discount")
            }
            return cell
        }
        else {
            let cell = tableView.dequeueReusableCell(withIdentifier: "tblcartcell5", for: indexPath) as! tblcartcell5
            if offerdetails.isEmpty == false
            {
                cell.lbloffercode.text = offerdetails["Offer_code"]
                cell.lblofferamt.text = "-₹\(Offer_amt)"
                cell.lblofferamt.isHidden = false
                cell.lbloffercode.isHidden = false
                Grand_Total = Item_total - Double(Offer_amt)
            }
            else{
                Grand_Total = Item_total
                cell.lbloffercode.isHidden = true
                cell.lblofferamt.isHidden = true
            }
            cell.lblitemtotal.text = "₹" + String(Item_total)
            cell.lblgrandtotal.text = "₹" + String(Grand_Total)
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        if indexPath.section == 1 && offerdetails.isEmpty == true
        {
            let stb = self.storyboard?.instantiateViewController(withIdentifier: "promocode")
            self.navigationController?.pushViewController(stb!, animated: true)
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        if indexPath.section == 0
        {
            if indexPath.row == 0
            {
                return 75.0
            }
            else if indexPath.row > 0 && indexPath.row <= item_Id.count
            {
                return 95.0
            }
            else
            {
                return 50.0
            }
        }
        else if indexPath.section == 1 {
            return 70.0
        }
        else {
            return 130.0
        }
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat
    {
        return 10.0
    }
    @IBAction func btndeleteitem(_ sender: UIButton)
    {
        if item_Id.count > 0
        {
            for i in 0...item_Id.count - 1
            {
                if item_Id[i] == sender.tag
                {
                    item_Qty[i] = item_Qty[i] - 1
                    if item_Qty[i] == 0
                    {
                        cartobj.deleteData(itemid: item_Id[i])
                        item_Id.remove(at: i)
                        item_Qty.remove(at: i)
                        item_Price.remove(at: i)
                        break
                    }
                    else
                    {
                        let cartdic = ["Res_id":Res_id,"Item_id":item_Id[i],"Item_qty":item_Qty[i],"Item_price":item_Price[i],"Is_veg":is_Veg[i]]
                        cartobj.update(cartdata: cartdic)
                        break
                    }
                }
            }
        }
        if item_Id.count == 0
        {
            createSubView()
        }
        getTotalAmount()
    }

    
    @IBAction func btnremove(_ sender: UIButton)
    {
        OfferDataObj.deleteData()
        offerdetails = [:]
        fatchCartData()
    }
    
    func createSubView()
    {
        subview = UIView(frame: CGRect(x: 0, y: 0, width: self.view.frame.width, height: self.view.frame.height))
        let x = self.view.frame.width / 2
        let y = self.view.frame.height - x
        let imgview = UIImageView(frame: CGRect(x: x/2, y: y/2, width: x, height: x))
        let lblmsg = UILabel(frame: CGRect(x: 50, y: y/2+200 , width: self.view.frame.width-100, height: 50))
        let lblmsg1 = UILabel(frame: CGRect(x: 50, y: y/2-50 , width: self.view.frame.width-100, height: 50))
        lblmsg1.text = "GOOD FOOD IS ALWAYS COOKING"
        lblmsg.font = UIFont.systemFont(ofSize: 15)
        lblmsg1.textAlignment = .center
        lblmsg.text = "Your cart is empty... Add Something from the menu..."
        lblmsg.numberOfLines = 2
        lblmsg.textAlignment = .center
        lblmsg.textColor = UIColor.lightGray
        subview.backgroundColor = UIColor.white
        imgview.image = UIImage(named: "cartfood.png")
        subview.addSubview(imgview)
        subview.addSubview(lblmsg1)
        subview.addSubview(lblmsg)
        self.view.addSubview(subview)
    }
    
    @IBAction func btnadditem(_ sender: UIButton)
    {
        if item_Id.count > 0
        {
            for i in 0...item_Id.count - 1
            {
                if item_Id[i] == sender.tag
                {
                    item_Qty[i] = item_Qty[i] + 1
                    let cartdic = ["Res_id":Res_id,"Item_id":item_Id[i],"Item_qty":item_Qty[i],"Item_price":item_Price[i],"Is_veg":is_Veg[i]]
                    cartobj.update(cartdata: cartdic)
                    getTotalAmount()
                    break
                }
            }
        }
        else
        {
        }
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat
    {
        return 10.0
    }
    
    func getTotalAmount()
    {
        Item_total = 0
        if item_Id.count > 0
        {
            for i in 0...item_Id.count - 1
            {
                let total = Double(item_Qty[i]) * Double(item_Price[i])
                Item_total = Item_total + total
                if offerdetails.isEmpty == false
                {
                    Offer_amt = Int(Item_total) * Int(offerdetails["Discount_of_per"]!)! / 100
                    if Offer_amt > Int(offerdetails["Max_discount"]!)!
                    {
                        Offer_amt = Int(offerdetails["Max_discount"]!)!
                    }
                }
                else {
                    Offer_amt = 0
                }
            }
            Cartplist = cartobj.getData()
           
        }
         tblview.reloadData()
    }
}
