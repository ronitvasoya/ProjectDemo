//
//  tblcartcell2.swift
//  ProjectDemo
//
//  Created by MAC2 on 15/02/19.
//  Copyright © 2019 TOPS. All rights reserved.
//

import UIKit

class tblcartcell2: UITableViewCell {

    @IBOutlet weak var lbltotalamt: UILabel!
    @IBOutlet weak var btndeleteitem: UIButton!
    @IBOutlet weak var btnadditem: UIButton!
    @IBOutlet weak var lblitemcounter: UILabel!
    @IBOutlet weak var lblitemprice: UILabel!
    @IBOutlet weak var lblitemname: UILabel!
    @IBOutlet weak var vegicon: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
