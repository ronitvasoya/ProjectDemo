//
//  payfororder.swift
//  ProjectDemo
//
//  Created by MAC2 on 23/02/19.
//  Copyright © 2019 TOPS. All rights reserved.
//

import UIKit
import SwiftyButton

class payfororder: UIViewController,UITableViewDelegate,UITableViewDataSource {

    let paymenttitle = ["Paytm","PhonePe","Google Pay","Freecharge","Pay On Delivery"]
    let paymentimage = ["paytm.png","phonepe.jpg","googlepay.png","freecharge.jpg","cod"]
    var Grand_Total:Double = 0.0
    var itemidstr:String = ""
    var itemqtystr:String = ""
    var subview = UIView()
    var item_Id:[Int] = []
    var item_Qty:[Int] = []
    var Res_id:Int = 0
    var Cust_id:Int = 0
    var Profile_Details:[String:String] = [:]
    let loginObj = LoginData()
    
    @IBOutlet weak var btnpayment: FlatButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        btnpayment.color = .red
        btnpayment.clipsToBounds = true
        btnpayment.cornerRadius  = 5
        checkLogin()
        btnpayment.isHidden = true
        Profile_Details = loginObj.getData()
        Cust_id = Int(Profile_Details["Cust_id"]!)!
    }
    
    override func viewWillAppear(_ animated: Bool) {
        navigationController?.navigationBar.isHidden = false
        tabBarController?.tabBar.isHidden = true
        let diff = UserDefaults.standard
        if diff.value(forKey: "Username") == nil
        {
            subview.isHidden = false
        }
        else{
            subview.isHidden = true
        }
    }
    
    func checkLogin() {
        let diff = UserDefaults.standard
        if diff.value(forKey: "Username") == nil
        {

            subview.frame = CGRect(x: 0, y: 67, width: self.view.frame.width, height: self.view.frame.height-67)
            subview.backgroundColor = UIColor.white
            subview.clipsToBounds = true
            subview.layer.opacity = 0.8
            subview.layer.shadowOffset = CGSize(width: 2, height: 2)
            subview.layer.shadowOpacity = 0.8
            let loginbtn = FlatButton(frame: CGRect(x: 15, y: self.view.frame.height/2-17, width: self.view.frame.width-30, height: 50))
            loginbtn.color = .red
            loginbtn.cornerRadius = 5
            loginbtn.setTitle("Login Now", for: .normal)
            loginbtn.titleLabel?.font = UIFont.systemFont(ofSize: 25)
            loginbtn.tintColor = UIColor.white
            loginbtn.addTarget(self, action: #selector(self.redirectLoginPage(_:)), for: .touchDown)
            subview.addSubview(loginbtn)
            self.view.addSubview(subview)
        }
    }
    
    func redirectLoginPage(_ sender:FlatButton) {
        let stb = self.storyboard?.instantiateViewController(withIdentifier: "cdr")
        self.navigationController?.pushViewController(stb!, animated: true)
    }
    
    @IBAction func btnpayment(_ sender: UIButton) {
        
    }
    
    func numberOfSections(in tableView: UITableView) -> Int
    {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return paymentimage.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "payforordercell", for: indexPath) as! payforordercell
        cell.lbltitle.text = paymenttitle[indexPath.row]
        cell.imgview.image = UIImage(named: paymentimage[indexPath.row])
        if indexPath.row == paymentimage.count - 1
        {
            cell.lblamount.isHidden = true
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return 60.0
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        let v1 = UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.size.width, height: 50))
        let lbl = UILabel(frame: CGRect(x: 10, y: 0, width:v1.frame.size.width, height: 50))
        lbl.text = "Pay ₹" + String(Grand_Total)
        lbl.font = UIFont.systemFont(ofSize: 25.0)
        v1.addSubview(lbl)
        return v1
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat
    {
        return 60.0
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        if indexPath.row == 0
        {
            btnpayment.isHidden = true
            let stb = self.storyboard?.instantiateViewController(withIdentifier: "paytm")
            self.navigationController?.pushViewController(stb!, animated: true)
        }
        else if indexPath.row == 1
        {
            btnpayment.isHidden = true
            let stb = self.storyboard?.instantiateViewController(withIdentifier: "phonepe")
            self.navigationController?.pushViewController(stb!, animated: true)
        }
        else if indexPath.row == 2
        {
            btnpayment.isHidden = true
            let stb = self.storyboard?.instantiateViewController(withIdentifier: "googlepay")
            self.navigationController?.pushViewController(stb!, animated: true)
        }
        else if indexPath.row == 3
        {
            btnpayment.isHidden = true
            let stb = self.storyboard?.instantiateViewController(withIdentifier: "freecharge")
            self.navigationController?.pushViewController(stb!, animated: true)
        }
        else
        {
            btnpayment.isHidden = false
            btnpayment.isEnabled = true
            btnpayment.setTitle("Pay using COD", for: .normal)
        }
        
    }
}
