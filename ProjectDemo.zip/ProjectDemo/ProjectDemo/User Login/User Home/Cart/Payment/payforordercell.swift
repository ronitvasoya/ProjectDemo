//
//  payforordercell.swift
//  ProjectDemo
//
//  Created by MAC2 on 23/02/19.
//  Copyright © 2019 TOPS. All rights reserved.
//

import UIKit

class payforordercell: UITableViewCell {

    @IBOutlet weak var lbltitle: UILabel!
    @IBOutlet weak var lblamount: UILabel!
    @IBOutlet weak var imgview: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }

}
