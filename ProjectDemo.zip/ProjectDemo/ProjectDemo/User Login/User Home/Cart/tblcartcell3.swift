//
//  tblcartcell3.swift
//  ProjectDemo
//
//  Created by MAC2 on 15/02/19.
//  Copyright © 2019 TOPS. All rights reserved.
//

import UIKit

class tblcartcell3: UITableViewCell {

    @IBOutlet weak var lblgrandtotal: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
