//
//  order_history.swift
//  ProjectDemo
//
//  Created by MAC2 on 25/01/19.
//  Copyright © 2019 TOPS. All rights reserved.
//

import UIKit

class order_history: UIViewController,UITableViewDelegate,UITableViewDataSource {

    @IBOutlet weak var tblview: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.navigationBar.isHidden = false
        tabBarController?.tabBar.isHidden = true
        tblview.frame = CGRect(x: 0, y: 67, width: self.view.frame.width, height: self.view.frame.height-67)
    }
 
    func numberOfSections(in tableView: UITableView) -> Int {
        return 3
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return 3
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {   if indexPath.row == 0
        {
            let cell = tableView.dequeueReusableCell(withIdentifier: "ordercell1", for: indexPath) as! ordercell1
            return cell
        }
    else if indexPath.row == 1
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ordercell2", for: indexPath) as! ordercell2
        return cell
        }
    else
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ordercell3", for: indexPath) as! ordercell3
        return cell
        }
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.row == 0
        {
            return 70.0
        }
        else if indexPath.row == 1
        {
            return 165.0
        }
        else
        {
            return 55.0
        }
    }
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        if section == 0
        {
            return "Order History"
        }
        else
        {
            return ""
        }
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        if section == 0
        {
            let v1 = UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.size.width, height: 50))
            let lbl = UILabel(frame: CGRect(x: 10, y: 0, width:v1.frame.size.width, height: 50))
            lbl.text = "Order History"
            lbl.font = UIFont.systemFont(ofSize: 25.0)
            v1.addSubview(lbl)
            return v1
        }
        else
        {
            let v1 = UIView()
            return v1
        }
    }
   
    
}
