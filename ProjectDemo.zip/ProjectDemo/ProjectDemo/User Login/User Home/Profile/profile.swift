import UIKit
import GoogleSignIn
import EasySocialButton
import SwiftyButton

class profile: UIViewController,UITableViewDelegate,UITableViewDataSource,CAAnimationDelegate {
    
    var tbl = UITableView()
    var hidemenu:Bool = true
    var time = Timer()
    var v = UIView()
    var  s = 0.0
    var Profile_Details:[String:String] = [:]
    let loginobj = LoginData()
    let cartobj = CartData()
    var iconarr1 = ["Cart1.png","cart3.png","favorite.png","chat.png"]
    var iconarr2 = ["tb1.png","tb.png","chat.png"]
    var iconarr3 = ["acsetting.png","payment.png","moresetting.png","review.png","logout.png"]
    var iconnamearr1 = ["Food Orders","Your Orders","Favorite Orders","Customor Service"]
    var iconnamearr2 = ["Table Bookings","Your Bookings","Customor Service"]
    var iconnamearr3 = ["Account Settings","Payment Options","More Settings","Review","LogOut"]
    
    @IBOutlet weak var imgview: UIImageView!
    @IBOutlet weak var lblUsername: UILabel!
    @IBOutlet weak var orderbtn: AZSocialButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tbl = UITableView(frame: CGRect(x: 0, y: 0, width: 0, height: self.view.frame.size.height), style: .grouped)
        tbl.dataSource = self
        tbl.delegate = self
        tbl.separatorStyle = .none
        tbl.scrollsToTop = false
        tbl.showsVerticalScrollIndicator = false
        tbl.showsHorizontalScrollIndicator = false
        v = UIView(frame:self.view.bounds)
        v.backgroundColor = UIColor.darkGray
        v.alpha = 0.0
        v.isMultipleTouchEnabled = false
        self.view.addSubview(v)
        
        let right = UISwipeGestureRecognizer(target: self, action: #selector(self.showmenu))
        let left = UISwipeGestureRecognizer(target: self, action: #selector(self.hide))
        left.direction = .left
        right.direction = .right
        v.addGestureRecognizer(right)
        v.addGestureRecognizer(left)
        self.view.addSubview(tbl)
        
        imgview.clipsToBounds = true
        imgview.layer.cornerRadius = 70.0
        orderBtn()
        checkLogin()
    }
    
    func setProfile() {
        Profile_Details.removeAll()
        Profile_Details = loginObj.getData()
        lblUsername.text = Profile_Details["Cust_name"]
        let str = "http://localhost/project/"
        if Profile_Details["Cust_image"] != "" && Profile_Details.isEmpty == false
        {
            let finalStr = str.appending(Profile_Details["Cust_image"]!)
            let url = URL(string: finalStr)
            do{
                let imgData = try Data.init(contentsOf: url!)
                imgview.image = UIImage(data: imgData)
            }catch{
                
            }
        }
    }
    
    func checkLogin() {
        let diff = UserDefaults.standard
        if diff.value(forKey: "Username") == nil
        {
            navigationController?.navigationBar.isHidden = true
            let subview = UIView(frame: self.view.bounds)
            subview.backgroundColor = UIColor.white
            subview.clipsToBounds = true
            subview.layer.opacity = 0.8
            subview.layer.shadowOffset = CGSize(width: 2, height: 2)
            subview.layer.shadowOpacity = 0.8
            let loginbtn = FlatButton(frame: CGRect(x: 15, y: self.view.frame.height/2+50, width: self.view.frame.width-30, height: 50))
            loginbtn.color = .red
            loginbtn.cornerRadius = 5
            loginbtn.setTitle("Login Now", for: .normal)
            loginbtn.titleLabel?.font = UIFont.systemFont(ofSize: 25)
            loginbtn.tintColor = UIColor.white
            loginbtn.addTarget(self, action: #selector(self.redirectLoginPage(_:)), for: .touchDown)
            subview.addSubview(loginbtn)
            self.view.addSubview(subview)
        }
    }
    
    func redirectLoginPage(_ sender:FlatButton) {
        let stb = self.storyboard?.instantiateViewController(withIdentifier: "cdr")
        self.navigationController?.pushViewController(stb!, animated: true)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        tabBarController?.tabBar.isHidden = false
        setProfile()
    }
    
    @IBAction func editbtn(_ sender: Any) {
        let stb = self.storyboard?.instantiateViewController(withIdentifier: "edit")
        self.navigationController?.pushViewController(stb!, animated: true)
    }
    
    @IBAction func orderBtnAcion(_ sender: AZSocialButton) {
        let stb = self.storyboard?.instantiateViewController(withIdentifier: "history")
        self.navigationController?.pushViewController(stb!, animated: true)
        
    }
    
   @objc func orderBtn() {
        orderbtn.frame = CGRect(x: 12, y: 300, width: 200, height: 40)
        orderbtn.animateInteraction = true
        orderbtn.useCornerRadius = true
        orderbtn.cornerRadius = 5
        orderbtn.highlightOnTouch = false
        orderbtn.setImage(UIImage(named: "cart4.png"), for: .normal)
        orderbtn.setTitle("   Your Orders >", for: [])
        orderbtn.setTitleColor(.black, for: [])
       orderbtn.titleLabel?.font = UIFont.systemFont(ofSize: 20)
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        hide()
    }
    
    @IBAction func btnitem(_ sender: UIBarButtonItem) {
        if hidemenu == true
        {
            showmenu()
        }
        else
        {
            hide()
        }
    }
    
   @objc func hide() {
        s = 0.5
        time = Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(self.test(_:)), userInfo: nil, repeats: true)
        UIView.beginAnimations(nil, context: nil)
        UIView.setAnimationDuration(0.5)
        UIView.setAnimationDelegate(self)
        tbl.frame = CGRect(x: -300, y: 0, width: 300, height: self.view.frame.size.height)
        UIView.commitAnimations()
        hidemenu = true
    }
    
    
    @IBAction func share(_ sender: UIBarButtonItem) {
        var arr : [Any] = []
        arr.append("Share Food Vector")
        let alt = UIActivityViewController(activityItems: arr, applicationActivities: nil)
        self.present(alt, animated: true, completion: nil)
    }
    
   @objc func showmenu()  {
        s = 0.0
        time = Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(self.test(_:)), userInfo: nil, repeats: true)
        UIView.beginAnimations(nil, context: nil)
        UIView.setAnimationDuration(0.5)
        UIView.setAnimationDelegate(self)
        tbl.frame = CGRect(x: 0, y: 0, width: 300, height: self.view.frame.size.height)
        UIView.commitAnimations()
        hidemenu = false
    }
    
   @objc func test(_ sender:Timer) {
        if hidemenu == false
        {
            if s <= 0.5
            {
                s = s + 0.1
                v.alpha = CGFloat(s)
            }
            else
            {
                time.invalidate()
            }
        }
        else
        {
            if s >= 0.0
            {
                s = s - 0.1
                v.alpha = CGFloat(s)
            }
            else
            {
                time.invalidate()
            }
        }
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 3
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0
        {
            return iconarr1.count
        }
        else if section == 1
        {
            return iconarr2.count
        }
        else
        {
            return iconarr3.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        if  indexPath.section == 0
        {
            cell.textLabel?.text = iconnamearr1[indexPath.row]
            cell.imageView?.image = UIImage(named: iconarr1[indexPath.row])
        }
        else if indexPath.section == 1
        {
            cell.textLabel?.text = iconnamearr2[indexPath.row]
            cell.imageView?.image = UIImage(named: iconarr2[indexPath.row])
        }
        else
        {
            cell.textLabel?.text = iconnamearr3[indexPath.row]
            cell.imageView?.image = UIImage(named: iconarr3[indexPath.row])
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if indexPath.section == 0
        {
            if indexPath.row == 1
            {
                let stb = self.storyboard?.instantiateViewController(withIdentifier: "history")
                self.navigationController?.pushViewController(stb!, animated: true)
            }
        }
        else if indexPath.section == 1
        {
            
        }
        else{
            if indexPath.row == 1 {
                let stb = self.storyboard?.instantiateViewController(withIdentifier: "payment")
                self.navigationController?.pushViewController(stb!, animated: true)
            }
            else if indexPath.row == 2 {
                let stb = self.storyboard?.instantiateViewController(withIdentifier: "moresetting")
                self.navigationController?.pushViewController(stb!, animated: true)
            }
            else if indexPath.row == 3 {
                let stb = self.storyboard?.instantiateViewController(withIdentifier: "review")
                self.navigationController?.pushViewController(stb!, animated: true)
            }
            else if indexPath.row == 4 {
                let alert = UIAlertController(title: "Logout", message: "Are You Sure You Want to Logout", preferredStyle: .alert);
                let yes = UIAlertAction(title: "Yes", style: .destructive)
                {
                    ACTION in
                    
                    GIDSignIn.sharedInstance().signOut()
                    let diff = UserDefaults.standard
                    diff.removeObject(forKey: "Username")
                    self.Profile_Details.removeAll()
                    loginObj.deleteData(dic: self.Profile_Details)
                    print(loginObj.getData())
                    self.cartobj.DeleteCart()
                    let stb = self.storyboard?.instantiateViewController(withIdentifier: "first")
                    self.navigationController?.pushViewController(stb!, animated: true)
                    
                }
                alert.addAction(yes);
                
                let no = UIAlertAction(title: "No", style: .default)
                {
                    ACTION in
                }
                alert.addAction(no);
                self.present(alert, animated: true, completion: nil);
                
            }
        }
        hide()
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        if indexPath.row == 0
        {
            return 50.0
        }
        else
        {
            return 40.0
        }
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 5.0
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 5.0
    }
}
