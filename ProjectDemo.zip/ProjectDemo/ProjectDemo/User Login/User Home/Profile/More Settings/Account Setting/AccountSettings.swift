import UIKit

class AccountSettings: UIViewController,UITableViewDelegate,UITableViewDataSource {

    let accountsetting = ["Delete Account","Change or Set Password"]
    var Profile_Details:[String:String] = [:]
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        Profile_Details = loginObj.getData()
    }
    
    func numberOfSections(in tableView: UITableView) -> Int
    {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return 2
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "accountsettingcell", for: indexPath) as! accountsettingcell
        cell.lbltitle.text = accountsetting[indexPath.row]
        return cell
    }
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        
            let v1 = UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.size.width, height: 50))
            let lbl = UILabel(frame: CGRect(x: 10, y: 0, width:v1.frame.size.width, height: 50))
            lbl.text = "Account Settings"
            lbl.font = UIFont.systemFont(ofSize: 25.0)
            v1.addSubview(lbl)
            return v1
    
        
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 50.0
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60.0
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        if indexPath.row == 0
        {
            let alert = UIAlertController(title: "Delete Account", message: "Are You Sure You Want to Delete Your Account", preferredStyle: .alert);
            let yes = UIAlertAction(title: "Yes", style: .destructive)
            {
                ACTION in
                
            }
            alert.addAction(yes);
            
            let no = UIAlertAction(title: "No", style: .default)
            {
                ACTION in
                
            }
            alert.addAction(no);
            self.present(alert, animated: true, completion: nil);
        }
        else
        {
            if Profile_Details["Cust_password"] != ""
            {
                let stb = self.storyboard?.instantiateViewController(withIdentifier: "changepassword")
                self.navigationController?.pushViewController(stb!, animated: true)
            }
            else
            {
                let stb = self.storyboard?.instantiateViewController(withIdentifier: "SetPassword")
                self.navigationController?.pushViewController(stb!, animated: true)
            }
        }
    }
}
