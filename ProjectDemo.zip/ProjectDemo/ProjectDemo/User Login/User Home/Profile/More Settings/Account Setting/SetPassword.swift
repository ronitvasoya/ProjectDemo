import UIKit
import SwiftyButton

class SetPassword: UIViewController {

    @IBOutlet weak var btnsetpassword: FlatButton!
    @IBOutlet weak var newpassword: UITextField!
    @IBOutlet weak var cnewpassword: UITextField!
    @IBOutlet weak var btnshowhide: UIButton!
    @IBOutlet weak var btnshowhide1: UIButton!
    
    var newpass:Bool = false
    var confpass:Bool = false
    var Profile_Details:[String:String] = [:]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        btnsetpassword.cornerRadius = 5
        btnsetpassword.color = .red
        btnsetpassword.frame = CGRect(x: 15, y: self.view.frame.height-75, width: self.view.frame.width-30, height: 53)
        btnsetpassword.isEnabled = false
        newpassword.isSecureTextEntry = true;
        cnewpassword.isSecureTextEntry = true;
    }
    
    override func viewWillAppear(_ animated: Bool) {
        navigationController?.navigationBar.isHidden = false
        tabBarController?.tabBar.isHidden = true
        Profile_Details = loginObj.getData()
    }
    
    @IBAction func btnSetNewPassword(_ sender: UIButton) {
        if newpassword.text! == cnewpassword.text!
        {
            let id = Profile_Details["Cust_id"]
            let url = URL(string: "http://localhost/project/Change_Password.php")
            let strBody = "Cust_password=\(newpassword.text!)&Cust_id=\(id!)"
            var request = URLRequest(url: url!);
            request.addValue(String(strBody.count), forHTTPHeaderField: "Content_Length")
            request.httpBody = strBody.data(using: String.Encoding.utf8)
            request.httpMethod = "POST"
            let session = URLSession.shared;
            let datatask = session.dataTask(with: request)
            {
                (data1, rsp, err) in
                DispatchQueue.main.async {
                    do
                    {
                        var jsondata = try JSONSerialization.jsonObject(with: data1!, options: []) as! [Any];
                        if jsondata.count > 0
                        {
                            let dic = jsondata[0] as! [String:String]
                            loginObj.insertData(dic: dic)
                            self.navigationController?.popViewController(animated: true)
                        }
                    }
                    catch{}
                }
            }
            datatask.resume();
        }
        else
        {
            let alert = UIAlertController(title: "Alert", message: "Confirm New Password Does Not Match", preferredStyle: .alert);
            let ok = UIAlertAction(title: "Ok", style: .default)
            {
                ACTION in
                
            }
            alert.addAction(ok);
            self.present(alert, animated: true, completion: nil);
        }
    }
    
    @IBAction func txtChangeNewPassword(_ sender: UITextField) {
        if obj.isValidPassword(pwd: newpassword.text!)
        {
            newpassword.rightViewMode = .never
            newpass = true
        }
        else
        {
            newpassword.rightViewMode = .whileEditing
            let imgview = UIImageView(image: UIImage(named: "help.png"))
            newpassword.rightView = imgview
            newpassword.clipsToBounds = true
            newpass = false
        }
        check(newpass: newpass, confpass: confpass)
    }
    
    @IBAction func txtchangeConfPassword(_ sender: UIButton) {
        if obj.isValidPassword(pwd: cnewpassword.text!)
        {
            cnewpassword.rightViewMode = .never
            confpass = true
        }
        else
        {
            cnewpassword.rightViewMode = .whileEditing
            let imgview = UIImageView(image: UIImage(named: "help.png"))
            cnewpassword.rightView = imgview
            cnewpassword.clipsToBounds = true
            confpass = false
        }
        check(newpass: newpass, confpass: confpass)
    }
    
    @IBAction func btnShowHide(_ sender: UIButton) {
        if btnshowhide.titleLabel?.text == "Show"
        {
            newpassword.isSecureTextEntry = false
            btnshowhide.setImage(UIImage(named: "if_eye_1545742.png"), for: .normal)
            btnshowhide.setTitle("Hide", for: .normal)
        }
        else
        {
            newpassword.isSecureTextEntry = true
            btnshowhide.setImage(UIImage(named: "if_icon-21-eye-hidden_314858.png"), for: .normal)
            btnshowhide.setTitle("Show", for: .normal)
        }
    }
    
    @IBAction func btnShowHide1(_ sender: UIButton) {
        if btnshowhide1.titleLabel?.text == "Show"
        {
            cnewpassword.isSecureTextEntry = false
            btnshowhide1.setImage(UIImage(named: "if_eye_1545742.png"), for: .normal)
            btnshowhide1.setTitle("Hide", for: .normal)
        }
        else
        {
            cnewpassword.isSecureTextEntry = true
            btnshowhide1.setImage(UIImage(named: "if_icon-21-eye-hidden_314858.png"), for: .normal)
            btnshowhide1.setTitle("Show", for: .normal)
        }
    }
    
    func check(newpass:Bool , confpass:Bool) {
        
        if newpass == true && confpass == true
        {
            btnsetpassword.isEnabled = true
        }
        else
        {
            btnsetpassword.isEnabled = false
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?)
    {
        self.view.endEditing(true)
    }
    
}
