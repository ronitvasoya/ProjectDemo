//
//  ChangePassword.swift
//  ProjectDemo
//
//  Created by MAC2 on 06/02/19.
//  Copyright © 2019 TOPS. All rights reserved.
//

import UIKit
import SwiftyButton


class ChangePassword: UIViewController
{
    @IBOutlet weak var btnchangepassword: FlatButton!
    @IBOutlet weak var currentpassword: UITextField!
    @IBOutlet weak var newpassword: UITextField!
    @IBOutlet weak var cnewpassword: UITextField!
    @IBOutlet weak var btnshowhide: UIButton!
    @IBOutlet weak var btnshowhide1: UIButton!
    @IBOutlet weak var btnshowhide2: UIButton!
    
    var currentpass:Bool = false
    var newpass:Bool = false
    var confpass:Bool = false
    var Profile_Details:[String:String] = [:]
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        btnchangepassword.cornerRadius = 5
        btnchangepassword.color = .red
        btnchangepassword.frame = CGRect(x: 15, y: self.view.frame.height-75, width: self.view.frame.width-30, height: 53)
        btnchangepassword.isEnabled = false
        currentpassword.isSecureTextEntry = true;
        newpassword.isSecureTextEntry = true;
        cnewpassword.isSecureTextEntry = true;
        Profile_Details = loginObj.getData()
    }
    
    @IBAction func btnchabgepassword(_ sender: UIButton) {
        if currentpassword.text! == Profile_Details["Cust_password"]!
        {
            if newpassword.text! == cnewpassword.text!
            {
                let dif = UserDefaults.standard
                let id = dif.value(forKey: "Cust_id") as! Int
                let url = URL(string: "http://localhost/project/Change_Password.php")
                let strBody = "Cust_password=\(newpassword.text!)&Cust_id=\(id)"
                var request = URLRequest(url: url!);
                request.addValue(String(strBody.count), forHTTPHeaderField: "Content_Length")
                request.httpBody = strBody.data(using: String.Encoding.utf8)
                request.httpMethod = "POST"
                let session = URLSession.shared;
                let datatask = session.dataTask(with: request)
                {
                    (data1, rsp, err) in
                    DispatchQueue.main.async {
                        do
                        {
                            var jsondata = try JSONSerialization.jsonObject(with: data1!, options: []) as! [Any];
                            if jsondata.count > 0
                            {
                                let dic = jsondata[0] as! [String:String]
                                loginObj.insertData(dic: dic)
                                self.navigationController?.popViewController(animated: true)
                            }
                        }
                        catch{}
                    }
                }
                datatask.resume();
            }
            else
            {
                let alert = UIAlertController(title: "Alert", message: "Confirm Password Does Not Match", preferredStyle: .alert);
                let ok = UIAlertAction(title: "Ok", style: .default)
                {
                    ACTION in
                
                }
                alert.addAction(ok);
                self.present(alert, animated: true, completion: nil);
            }
        }
        else
        {
            let alert = UIAlertController(title: "Alert", message: "Current Password Does Not Match", preferredStyle: .alert);
            let ok = UIAlertAction(title: "Ok", style: .default)
            {
                ACTION in
                
            }
            alert.addAction(ok);
            self.present(alert, animated: true, completion: nil);
        }
    }
    
    @IBAction func btnshowhide(_ sender: Any)
    {
        if btnshowhide.titleLabel?.text == "Show"
        {
            currentpassword.isSecureTextEntry = false
            btnshowhide.setImage(UIImage(named: "if_eye_1545742.png"), for: .normal)
            btnshowhide.setTitle("Hide", for: .normal)
        }
        else
        {
            currentpassword.isSecureTextEntry = true
            btnshowhide.setImage(UIImage(named: "if_icon-21-eye-hidden_314858.png"), for: .normal)
            btnshowhide.setTitle("Show", for: .normal)
        }
    }
    
    @IBAction func btnshowhide1(_ sender: Any)
    {
        if btnshowhide1.titleLabel?.text == "Show"
        {
            newpassword.isSecureTextEntry = false
            btnshowhide1.setImage(UIImage(named: "if_eye_1545742.png"), for: .normal)
            btnshowhide1.setTitle("Hide", for: .normal)
        }
        else
        {
           newpassword.isSecureTextEntry = true
            btnshowhide1.setImage(UIImage(named: "if_icon-21-eye-hidden_314858.png"), for: .normal)
            btnshowhide1.setTitle("Show", for: .normal)
        }
    }
    
    @IBAction func btnshowhide2(_ sender: Any)
    {
        if btnshowhide2.titleLabel?.text == "Show"
        {
            cnewpassword.isSecureTextEntry = false
            btnshowhide2.setImage(UIImage(named: "if_eye_1545742.png"), for: .normal)
            btnshowhide2.setTitle("Hide", for: .normal)
        }
        else
        {
          cnewpassword.isSecureTextEntry = true
            btnshowhide2.setImage(UIImage(named: "if_icon-21-eye-hidden_314858.png"), for: .normal)
            btnshowhide2.setTitle("Show", for: .normal)
        }
    }
    
    @IBAction func txtcurrentpassword(_ sender: Any)
    {
        if obj.isValidPassword(pwd: currentpassword.text!)
        {
            currentpassword.rightViewMode = .never
            currentpass = true
        }
        else
        {
            currentpassword.rightViewMode = .whileEditing
            let imgview = UIImageView(image: UIImage(named: "help.png"))
            currentpassword.rightView = imgview
            currentpassword.clipsToBounds = true
            currentpass = false
        }
        check(currentpass: currentpass, newpass: newpass, confpass: confpass)
    }
    
    @IBAction func txtnewpassword(_ sender: Any)
    {
        if obj.isValidPassword(pwd: newpassword.text!)
        {
            newpassword.rightViewMode = .never
            newpass = true
        }
        else
        {
            newpassword.rightViewMode = .whileEditing
            let imgview = UIImageView(image: UIImage(named: "help.png"))
            newpassword.rightView = imgview
            newpassword.clipsToBounds = true
            newpass = false
        }
        check(currentpass: currentpass, newpass: newpass, confpass: confpass)
    }
    
    @IBAction func txtcnewpassword(_ sender: Any)
    {
        if obj.isValidPassword(pwd: cnewpassword.text!)
        {
            cnewpassword.rightViewMode = .never
            confpass = true
        }
        else
        {
            cnewpassword.rightViewMode = .whileEditing
            let imgview = UIImageView(image: UIImage(named: "help.png"))
            cnewpassword.rightView = imgview
            cnewpassword.clipsToBounds = true
            confpass = false
        }
        check(currentpass: currentpass, newpass: newpass, confpass: confpass)
    }
    
    func check(currentpass:Bool, newpass:Bool , confpass:Bool) {
        
        if currentpass == true && newpass == true && confpass == true
        {
            btnchangepassword.isEnabled = true
        }
        else
        {
            btnchangepassword.isEnabled = false
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?)
    {
        self.view.endEditing(true)
    }

}
