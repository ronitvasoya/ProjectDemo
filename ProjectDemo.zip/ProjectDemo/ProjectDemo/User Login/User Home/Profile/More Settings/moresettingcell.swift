//
//  moresettingcell.swift
//  ProjectDemo
//
//  Created by MAC on 28/01/19.
//  Copyright © 2019 TOPS. All rights reserved.
//

import UIKit

class moresettingcell: UITableViewCell {

    @IBOutlet weak var lbltitle: UILabel!
    @IBOutlet weak var lblsubtitle: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
