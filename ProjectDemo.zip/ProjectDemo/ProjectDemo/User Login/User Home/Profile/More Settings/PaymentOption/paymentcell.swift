//
//  paymentcell.swift
//  ProjectDemo
//
//  Created by MAC2 on 07/02/19.
//  Copyright © 2019 TOPS. All rights reserved.
//

import UIKit

class paymentcell: UITableViewCell {

    @IBOutlet weak var lbltitle: UILabel!
    
    @IBOutlet weak var imgview: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()

    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
