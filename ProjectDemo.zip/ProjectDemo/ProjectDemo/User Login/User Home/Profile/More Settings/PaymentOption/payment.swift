//
//  payment.swift
//  ProjectDemo
//
//  Created by MAC2 on 25/01/19.
//  Copyright © 2019 TOPS. All rights reserved.
//

import UIKit

class payment: UIViewController,UITableViewDelegate,UITableViewDataSource {

    let paymenttitle = ["Paytm","PhonePe","Google Pay","Freecharge"]
    let paymentimage = ["paytm.png","phonepe.jpg","googlepay.png","freecharge.jpg"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationController?.navigationBar.isHidden = false
        tabBarController?.tabBar.isHidden = true
    }
    
    func numberOfSections(in tableView: UITableView) -> Int
    {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return paymentimage.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "paymentcell", for: indexPath) as! paymentcell
        cell.lbltitle.text = paymenttitle[indexPath.row]
        cell.imgview.image = UIImage(named: paymentimage[indexPath.row])
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return 60.0
    }
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        let v1 = UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.size.width, height: 50))
        let lbl = UILabel(frame: CGRect(x: 10, y: 0, width:v1.frame.size.width, height: 50))
        lbl.text = "Payment Options"
        lbl.font = UIFont.systemFont(ofSize: 25.0)
        v1.addSubview(lbl)
        return v1
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat
    {
        return 50.0
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        if indexPath.row == 0
        {
            let stb = self.storyboard?.instantiateViewController(withIdentifier: "paytm")
            self.navigationController?.pushViewController(stb!, animated: true)
        }
        else if indexPath.row == 1
        {
            let stb = self.storyboard?.instantiateViewController(withIdentifier: "phonepe")
            self.navigationController?.pushViewController(stb!, animated: true)
        }
        else if indexPath.row == 2
        {
            let stb = self.storyboard?.instantiateViewController(withIdentifier: "googlepay")
            self.navigationController?.pushViewController(stb!, animated: true)
        }
        else
        {
            let stb = self.storyboard?.instantiateViewController(withIdentifier: "freecharge")
            self.navigationController?.pushViewController(stb!, animated: true)
        }
    }
  

}
