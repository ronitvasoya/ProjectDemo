import UIKit
import SwiftyButton

class freecharge: UIViewController {

    @IBOutlet weak var txtemail: UITextField!
    @IBOutlet weak var txtphno: UITextField!
   
    @IBOutlet weak var btnsave: FlatButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setview()
    }
    
    func setview() {
        btnsave.color = .red
        btnsave.cornerRadius = 5
        btnsave.frame =  CGRect(x: 15, y: self.view.frame.height-75, width: self.view.frame.width-30, height: 53)
        txtemail.frame = CGRect(x: 15, y: 180, width: self.view.frame.width-50, height: 55)
        txtphno.frame = CGRect(x: 15, y: 255, width: self.view.frame.width-50, height: 55)
    }

    @IBAction func btnsave(_ sender: Any){
        
    }
    
    @IBAction func txtemail(_ sender: Any) {
        
    }
    
    @IBAction func tctphno(_ sender: Any) {
        
    }
    
}
