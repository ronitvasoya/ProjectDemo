//
//  paytm.swift
//  ProjectDemo
//
//  Created by MAC2 on 07/02/19.
//  Copyright © 2019 TOPS. All rights reserved.
//

import UIKit
import SwiftyButton

class paytm: UIViewController {

    @IBOutlet weak var txtemail: UITextField!
    @IBOutlet weak var txtphno: UITextField!
    
    
    @IBOutlet weak var btnsave: FlatButton!
    override func viewDidLoad()
    {
        super.viewDidLoad()
        btnsave.color = .red
        btnsave.cornerRadius = 5
        btnsave.frame =  CGRect(x: 15, y: self.view.frame.height-75, width: self.view.frame.width-30, height: 53)
    }
    
    
    
    @IBAction func txtphno(_ sender: Any) {
       
    }
    
    @IBAction func txtemail(_ sender: Any) {
        
    }
    
    @IBAction func btnsave(_ sender: Any) {
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
}
