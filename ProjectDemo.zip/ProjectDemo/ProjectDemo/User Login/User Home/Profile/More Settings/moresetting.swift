import UIKit

class moresetting: UIViewController,UITableViewDelegate,UITableViewDataSource {

    
    let MoreSettingTitle = ["Edit Profile","Connected Accounts","Account Settings"]
    let MoreSettingSubTitle = ["Change your name and profile photo","Facebook, Gmail permissions","Change your password or delete your account."]
    
    @IBOutlet weak var tblsetting: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tabBarController?.tabBar.isHidden = true
        tblsetting.frame = CGRect(x: 0, y: 67, width: self.view.frame.width, height: self.view.frame.height-67)
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return MoreSettingTitle.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "moresettingcell", for: indexPath) as! moresettingcell
        cell.lbltitle.text = MoreSettingTitle[indexPath.row]
        cell.lblsubtitle.text = MoreSettingSubTitle[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
            return "Settings"
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 50.0
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
            let v1 = UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.size.width, height: 50))
            let lbl = UILabel(frame: CGRect(x: 10, y: 0, width:v1.frame.size.width, height: 50))
            lbl.text = "Settings"
            lbl.font = UIFont.systemFont(ofSize: 25.0)
            v1.addSubview(lbl)
            return v1
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.row == 0
        {
            let stb = self.storyboard?.instantiateViewController(withIdentifier: "edit")
            self.navigationController?.pushViewController(stb!, animated: true)
        }
        else if indexPath.row == 2
        {
            let stb = self.storyboard?.instantiateViewController(withIdentifier: "accountsetting")
            self.navigationController?.pushViewController(stb!, animated: true)
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 70.0
    }
}
