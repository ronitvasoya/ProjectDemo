//
//  ordercell2.swift
//  ProjectDemo
//
//  Created by MAC2 on 25/01/19.
//  Copyright © 2019 TOPS. All rights reserved.
//

import UIKit

class ordercell2: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    @IBOutlet weak var lblitemdetails: UILabel!
    
    @IBOutlet weak var itemlbl: UILabel!
    
    @IBOutlet weak var orderlbl: UILabel!
    @IBOutlet weak var datelbl: UILabel!
    
    @IBOutlet weak var amountlbl: UILabel!
    
    @IBOutlet weak var lbl: UILabel!
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
