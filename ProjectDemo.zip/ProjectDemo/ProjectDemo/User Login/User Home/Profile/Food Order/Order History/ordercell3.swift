//
//  ordercell3.swift
//  ProjectDemo
//
//  Created by MAC2 on 25/01/19.
//  Copyright © 2019 TOPS. All rights reserved.
//

import UIKit

class ordercell3: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    @IBOutlet weak var deliveredlbl: UILabel!
    
    @IBOutlet weak var ratinglbl: UILabel!
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
