//
//  customerservicecell.swift
//  ProjectDemo
//
//  Created by MAC2 on 27/02/19.
//  Copyright © 2019 TOPS. All rights reserved.
//

import UIKit

class customerservicecell: UITableViewCell {

    @IBOutlet weak var lblname: UILabel!
    @IBOutlet weak var imgview: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
       
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

       
    }

}
