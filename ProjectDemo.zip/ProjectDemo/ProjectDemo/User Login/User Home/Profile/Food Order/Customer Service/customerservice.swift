//
//  customerservice.swift
//  ProjectDemo
//
//  Created by MAC2 on 27/02/19.
//  Copyright © 2019 TOPS. All rights reserved.
//

import UIKit

class customerservice: UIViewController,UITableViewDelegate,UITableViewDataSource {

    var arr = ["I have a query related to placing an order","I want to cancel my order","I am unable to login on Food Vector","I have a payment or refund related query","I have a coupon related query"]
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    override func viewWillAppear(_ animated: Bool)
    {
        navigationController?.navigationBar.isHidden = false
        tabBarController?.tabBar.isHidden = true
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return 5
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "customerservicecell", for: indexPath) as! customerservicecell
        cell.lblname.text = arr[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60.0
    }

    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return "I have an issue with.."
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let v1 = UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.size.width, height: 50))
        let lbl = UILabel(frame: CGRect(x: 10, y: 0, width:v1.frame.size.width, height: 50))
        lbl.text = "I have an issue with.."
        lbl.font = UIFont.systemFont(ofSize: 25.0)
        v1.addSubview(lbl)
        return v1
    }
}
