//
//  edit_profile.swift
//  ProjectDemo
//
//  Created by MAC2 on 25/01/19.
//  Copyright © 2019 TOPS. All rights reserved.
//

import UIKit
import SwiftyButton

class edit_profile: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate {

    @IBOutlet weak var imageviewprofile: UIImageView!
    @IBOutlet weak var txtUpdatename: UITextField!
    @IBOutlet weak var txtUpdatephno: UITextField!
    @IBOutlet weak var txtUpdatecity: UITextField!
    @IBOutlet weak var btnsave: FlatButton!
    
    
    var name:Bool = true
    var phno:Bool = true
    var city:Bool = false
    var Profile_Details:[String:String] = [:]
    var Change_Profile_image:Bool = false
    let loginObj = LoginData()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        btnsave.color = .red
        btnsave.cornerRadius = 5
        navigationController?.navigationBar.isHidden = false
        tabBarController?.tabBar.isHidden = true
        btnsave.isEnabled = false
    }
    
    override func viewWillAppear(_ animated: Bool) {
        if Change_Profile_image == false
        {
            setProfile()
        }
    }
    
    func setProfile() {
        imageviewprofile.clipsToBounds = true
        imageviewprofile.layer.cornerRadius = 25.0
        btnsave.frame = CGRect(x: 15, y: self.view.frame.height-65, width: self.view.frame.width-30, height: 53)
        Profile_Details = loginObj.getData()
        txtUpdatename.text = Profile_Details["Cust_name"]
        if Profile_Details["Cust_phno"] != "0" {
            txtUpdatephno.text = Profile_Details["Cust_phno"]
        }
        txtUpdatecity.text =  Profile_Details["Cust_city"]
        let str = "http://localhost/project/"
        if Profile_Details["Cust_image"] != ""
        {
            let finalStr = str.appending(Profile_Details["Cust_image"]!)
            let url = URL(string: finalStr)
            do{
                let imgData = try Data.init(contentsOf: url!)
                imageviewprofile.image = UIImage(data: imgData)
            }catch{
                
            }
        }
    }
    
    @IBAction func SaveProfile(_ sender: UIButton) {
        Profile_Details["Cust_name"] = txtUpdatename.text
        Profile_Details["Cust_phno"] = txtUpdatephno.text
        Profile_Details["Cust_city"] = txtUpdatecity.text
        let id = Profile_Details["Cust_id"]
        let url = URL(string: "http://localhost/project/Update_Profile.php")
        let strBody = "Cust_name=\(txtUpdatename.text!)&Cust_id=\(id!)&Cust_phno=\(txtUpdatephno.text!)&Cust_city=\(txtUpdatecity.text!)"
        var request = URLRequest(url: url!);
        request.addValue(String(strBody.count), forHTTPHeaderField: "Content_Length")
        request.httpBody = strBody.data(using: String.Encoding.utf8)
        request.httpMethod = "POST"
        let session = URLSession.shared;
        let datatask = session.dataTask(with: request)
        {
            (data1, rsp, err) in
            DispatchQueue.main.async {
                do
                {
                    var jsondata = try JSONSerialization.jsonObject(with: data1!, options: []) as! [Any];
                    if jsondata.count > 0
                    {
                        let dic = jsondata[0] as! [String:String]
                        self.loginObj.insertData(dic: dic)
                        self.Profile_Details.removeAll()
                        self.Profile_Details = self.loginObj.getData()
                        if self.Change_Profile_image == false
                        {
                            self.navigationController?.popViewController(animated: true)
                        }
                    }
                }
                catch
                {
                }
            }
            
        }
        datatask.resume();
        
        if Change_Profile_image == true
        {
            let id = Profile_Details["Cust_id"]!
            let imgdata = UIImageJPEGRepresentation(imageviewprofile.image!, 2)
            let base64str = imgdata?.base64EncodedString(options: Data.Base64EncodingOptions.lineLength64Characters)
            let url = URL(string: "http://localhost/project/Update_Profile_image.php")
            let strbody = "Cust_id=\(id)&Cust_image=\(base64str!)"
            var request = URLRequest(url: url!)
            request.addValue(String(strbody.count), forHTTPHeaderField: "Content_Length")
            request.httpBody = strbody.data(using: String.Encoding.utf8)
            request.httpMethod = "POST"
            let session = URLSession.shared
            let datatask = session.dataTask(with: request) { (data, resp, err) in
                DispatchQueue.main.async {
                    do
                    {
                        var jsondata = try JSONSerialization.jsonObject(with: data!, options: []) as! [Any];
                        if jsondata.count > 0
                        {
                            let dic = jsondata[0] as! [String:String]
                            self.loginObj.insertData(dic: dic)
                            self.Profile_Details.removeAll()
                            self.Profile_Details = self.loginObj.getData()
                            self.navigationController?.popViewController(animated: true)
                        }
                    }
                    catch
                    {
                    }
                }
            }
            datatask.resume()
        }
    }
    
    @IBAction func Editphoto(_ sender: UIButton) {
        let picker = UIImagePickerController()
        picker.sourceType = .photoLibrary
        picker.delegate = self
        self.present(picker, animated: true, completion: nil)
        Change_Profile_image = true
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        
        let img1 = info[UIImagePickerControllerOriginalImage] as! UIImage
        imageviewprofile.image = img1
        self.dismiss(animated: true, completion: nil)
    }
    @IBAction func txtchangename(_ sender: UITextField) {
        if txtUpdatename.text?.count == 0
        {
            btnsave.isEnabled = false
        }
        else{
            btnsave.isEnabled = true
        }
        if obj.isValidName(name: txtUpdatename.text!)
        {
            name = true
        }
        else
        {
            name = false
        }
        check(name: name, phno: phno, city: city)
    }
    
    @IBAction func txtchangephno(_ sender: UITextField) {
        if txtUpdatephno.text?.count == 0
        {
            btnsave.isEnabled = false
        }
        else{
            btnsave.isEnabled = true
        }
        if obj.isValidMobile(mobile: txtUpdatephno.text!)
        {
            phno = true
        }
        else
        {
            phno = false
        }
        check(name: name, phno: phno, city: city)
    }
    @IBAction func txtchangecity(_ sender: UITextField) {
        if txtUpdatecity.text?.count == 0
        {
            btnsave.isEnabled = false
        }
        else{
            btnsave.isEnabled = true
        }
        if obj.isValidName(name: txtUpdatecity.text!)
        {
            city = true
        }
        else
        {
            city = false
        }
        check(name: name, phno: phno, city: city)
    }
    
   
    func check(name:Bool, phno:Bool, city:Bool) {
        
        if name == true && phno == true && city == true
        {
            btnsave.isEnabled = true
        }
        else
        {
            btnsave.isEnabled = false
        }
        
    }
}
