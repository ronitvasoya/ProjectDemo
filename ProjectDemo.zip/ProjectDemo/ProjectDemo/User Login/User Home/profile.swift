//
//  profile.swift
//  ProjectDemo
//
//  Created by MAC2 on 09/01/19.
//  Copyright © 2019 TOPS. All rights reserved.
//

import UIKit
class profile: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.navigationBar.isHidden = true
          
    }

}
