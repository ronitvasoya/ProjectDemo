//
//  delogin.swift
//  ProjectDemo
//
//  Created by MAC2 on 02/01/19.
//  Copyright © 2019 TOPS. All rights reserved.
//

import UIKit
import SwiftyButton

class delogin: UIViewController {

    @IBOutlet weak var email: UITextField!
    @IBOutlet weak var pass: UITextField!
    
    @IBOutlet weak var btnshowhide: UIButton!
    @IBOutlet weak var delogin: FlatButton!
    override func viewDidLoad() {
        super.viewDidLoad()

        delogin.frame = CGRect(x: 20, y: 350 , width: self.view.frame.width-40, height: 50)
        delogin.color = .red
        delogin.cornerRadius  = 5
        //delogin.isEnabled = false
        pass.isSecureTextEntry = true;
        createnavbar()
    }
    
    @IBAction func deloginAction(_ sender: Any) {
    }
    
    @IBAction func btnshowhide(_ sender: UIButton)
    {
        if btnshowhide.titleLabel?.text == "Show"
        {
            pass.isSecureTextEntry = false
            btnshowhide.setImage(UIImage(named: "if_eye_1545742.png"), for: .normal)
            btnshowhide.setTitle("Hide", for: .normal)
        }
        else
        {
            pass.isSecureTextEntry = true
            btnshowhide.setImage(UIImage(named: "if_icon-21-eye-hidden_314858.png"), for: .normal)
            btnshowhide.setTitle("Show", for: .normal)
        }
    }
    func createnavbar()
    {
        let btn = UIButton(type:  .custom)
        btn.setImage(UIImage(named: "cross16.png"), for: .normal)
        btn.addTarget(self, action: #selector(self.test(_:)), for: .touchDown)
        btn.frame = CGRect(x: 15, y: 40, width: 30, height: 30)
        self.view.addSubview(btn)
    }
    func test(_ sender:UIButton) {
        navigationController?.popViewController(animated: true)
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
}
