-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Feb 28, 2019 at 01:57 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sutex`
--

-- --------------------------------------------------------

--
-- Table structure for table `Application_Offer`
--

CREATE TABLE `Application_Offer` (
  `Offer_id` int(5) NOT NULL,
  `Offer_code` varchar(20) NOT NULL,
  `Offer_description` varchar(300) NOT NULL,
  `Created_on` date NOT NULL,
  `Expired_on` date NOT NULL,
  `Discount_of_per` int(5) NOT NULL,
  `Max_discount` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Application_Offer`
--

INSERT INTO `Application_Offer` (`Offer_id`, `Offer_code`, `Offer_description`, `Created_on`, `Expired_on`, `Discount_of_per`, `Max_discount`) VALUES
(1, 'PARTY', 'Get 25% OFF Up to 75.', '2019-02-01', '2019-03-31', 25, 75),
(2, 'TASTY300', 'Get 30% OFF up to 300.', '2019-02-01', '2019-03-31', 30, 300),
(3, 'TASTYALL', 'Get 50% OFF up to 100.', '2019-02-01', '2019-03-31', 50, 100);

-- --------------------------------------------------------

--
-- Table structure for table `Category`
--

CREATE TABLE `Category` (
  `Category_id` int(3) NOT NULL,
  `Category_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Category`
--

INSERT INTO `Category` (`Category_id`, `Category_name`) VALUES
(1, 'Punjabi'),
(2, 'South Indian'),
(3, 'Fast Food'),
(4, 'Chinese'),
(5, 'Gujarati'),
(6, 'Continental'),
(7, 'Dessert'),
(8, 'Snacks'),
(9, 'Beverages'),
(10, 'Rice & Noodles');

-- --------------------------------------------------------

--
-- Table structure for table `Customer_Details`
--

CREATE TABLE `Customer_Details` (
  `Cust_id` int(5) NOT NULL,
  `Cust_name` varchar(50) NOT NULL,
  `Cust_phno` bigint(10) NOT NULL,
  `Cust_email` varchar(100) NOT NULL,
  `Cust_password` varchar(30) NOT NULL,
  `Cust_city` varchar(20) NOT NULL,
  `Cust_image` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Customer_Details`
--

INSERT INTO `Customer_Details` (`Cust_id`, `Cust_name`, `Cust_phno`, `Cust_email`, `Cust_password`, `Cust_city`, `Cust_image`) VALUES
(1, 'Ronit Vasoya', 7575844610, 'vasoyaronit@gmail.com', 'Ronit123@', 'Surat', 'Customer_image/5c710d977eaf1.png'),
(2, 'Mansi Shah', 9624854979, 'mansishah4369@gmail.com', 'mansi123@', 'Surat', 'Customer_image/5c74d094d7ea0.png');

-- --------------------------------------------------------

--
-- Table structure for table `DE_Details`
--

CREATE TABLE `DE_Details` (
  `DE_id` int(5) NOT NULL,
  `DE_name` varchar(50) NOT NULL,
  `DE_phno` bigint(10) NOT NULL,
  `DE_email` varchar(100) NOT NULL,
  `DE_image` varchar(50) NOT NULL,
  `Create_date` date NOT NULL,
  `Is_active` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Item_Details`
--

CREATE TABLE `Item_Details` (
  `Item_id` bigint(10) NOT NULL,
  `Item_name` varchar(30) NOT NULL,
  `Item_image` varchar(50) NOT NULL,
  `Item_price` int(10) NOT NULL,
  `Is_available` tinyint(1) NOT NULL,
  `Is_veg` tinyint(1) NOT NULL,
  `Category_id` int(3) NOT NULL,
  `Res_id` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Item_Details`
--

INSERT INTO `Item_Details` (`Item_id`, `Item_name`, `Item_image`, `Item_price`, `Is_available`, `Is_veg`, `Category_id`, `Res_id`) VALUES
(1, 'Veg Cheese Frankie', 'cfk.jpg', 35, 1, 1, 3, 4),
(2, 'Paneer Cheese Frankie', 'pcfk.png', 100, 1, 1, 3, 4),
(3, 'Chhole Bhature', 'cbk.jpg', 75, 1, 1, 8, 4),
(4, 'Samosa', 'sk.jpg', 30, 1, 1, 8, 4),
(5, 'Margherita', 'md.jpg', 99, 1, 1, 3, 1),
(6, 'Farmhouse', 'fd.jpg', 205, 1, 1, 3, 1),
(7, 'Peppy Paneer', 'ppd.jpg', 205, 1, 1, 3, 1),
(8, 'Garlic Breadsticks', 'gbd.jpg', 95, 1, 1, 3, 1),
(9, 'Veg Maharaja Mac Meal (R)', 'mmmcd.jpg', 209, 1, 1, 3, 2),
(10, 'Veg Maharaja Mac Meal (M)', 'mmmcd.jpg', 249, 1, 1, 3, 2),
(11, 'Veg Maharaja Mac Meal (L)', 'mmmcd.jpg', 299, 1, 1, 3, 2),
(12, 'Veg Maharaja Mac', 'mmcd.png', 169, 1, 1, 3, 2),
(13, 'Big Spicy Paneer Wrap Meal (R)', 'bspwmcd.jpeg', 199, 1, 1, 3, 2),
(14, 'Big Spicy Paneer Wrap Meal (M)', 'bspwmcd.jpeg', 229, 1, 1, 3, 2),
(15, 'Big Spicy Paneer Wrap Meal (L)', 'bspwmcd.jpeg', 269, 1, 1, 3, 2),
(16, 'Mcflurry oreo small', 'mosmcd.jpg', 68, 1, 1, 7, 2),
(17, 'Choco hazelnut Shake', 'chs.jpg', 171, 1, 1, 9, 2),
(18, 'Salsa Chessy Masala Wedges (M)', 'scmw.jpg', 105, 1, 1, 3, 2),
(19, 'McAloo Tikki', 'mamcd.jpg', 45, 1, 1, 3, 2),
(20, 'Manchurian Gravy', 'mw.jpg', 159, 1, 1, 4, 3),
(21, 'Chilli Garlic Rice', 'cgrw.jpg', 199, 1, 1, 10, 3),
(22, 'Cilantro Rice', 'crw.jpg', 209, 1, 1, 10, 3),
(23, 'American Chopsuey', 'acw.jpeg', 209, 1, 1, 10, 3),
(24, 'Chilli Garlic Noodles', 'cgnw.jpg', 186, 1, 1, 10, 3),
(25, 'Spring Roll', 'srw.jpg', 149, 1, 1, 3, 3);

-- --------------------------------------------------------

--
-- Table structure for table `Offer_Restaurant`
--

CREATE TABLE `Offer_Restaurant` (
  `Offer_id` int(5) NOT NULL,
  `Offer_code` varchar(20) NOT NULL,
  `Offer_image` varchar(50) NOT NULL,
  `Created_on` date NOT NULL,
  `Expiry_date` date NOT NULL,
  `Res_id` int(5) NOT NULL,
  `Discount_of_per` int(5) NOT NULL,
  `Max_discount` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Offer_Restaurant`
--

INSERT INTO `Offer_Restaurant` (`Offer_id`, `Offer_code`, `Offer_image`, `Created_on`, `Expiry_date`, `Res_id`, `Discount_of_per`, `Max_discount`) VALUES
(1, 'UPBOGO', 'Offer_image/dominosoffer.jpg', '2019-02-01', '2019-02-28', 1, 50, 100),
(2, 'TASTY', 'Offer_image/kailashoffer.jpg', '2019-02-01', '2019-02-28', 4, 50, 150),
(3, 'MC50', 'Offer_image/mcdoffer.jpg', '2019-02-01', '2019-02-28', 2, 50, 100),
(4, 'TASTY', 'Offer_image/wofoffer.jpg', '2019-02-01', '2019-02-28', 3, 50, 150);

-- --------------------------------------------------------

--
-- Table structure for table `Order_Details`
--

CREATE TABLE `Order_Details` (
  `Order_id` bigint(10) NOT NULL,
  `Order_date` datetime NOT NULL,
  `Payment_method` varchar(20) NOT NULL,
  `Process_status` varchar(10) NOT NULL,
  `Total_amount` int(5) NOT NULL,
  `Cust_address` varchar(200) NOT NULL,
  `Cust_latitude` varchar(20) NOT NULL,
  `Cust_longitude` varchar(20) NOT NULL,
  `Offer_id` int(3) NOT NULL,
  `Res_id` int(5) NOT NULL,
  `DE_id` int(5) NOT NULL,
  `Cust_id` int(5) NOT NULL,
  `Item_id` varchar(500) NOT NULL,
  `Quantity` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Payment_Details`
--

CREATE TABLE `Payment_Details` (
  `Payment_id` bigint(10) NOT NULL,
  `Order_id` bigint(10) NOT NULL,
  `Payment_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Restaurant_Details`
--

CREATE TABLE `Restaurant_Details` (
  `Res_id` int(5) NOT NULL,
  `Res_name` varchar(50) NOT NULL,
  `Res_image` varchar(50) NOT NULL,
  `Res_address` varchar(200) NOT NULL,
  `Res_city` varchar(20) NOT NULL,
  `Res_Email` varchar(100) NOT NULL,
  `Res_phno` bigint(10) NOT NULL,
  `Is_active` tinyint(1) NOT NULL,
  `Rating` float NOT NULL,
  `Res_latitude` varchar(20) NOT NULL,
  `Res_longitude` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Restaurant_Details`
--

INSERT INTO `Restaurant_Details` (`Res_id`, `Res_name`, `Res_image`, `Res_address`, `Res_city`, `Res_Email`, `Res_phno`, `Is_active`, `Rating`, `Res_latitude`, `Res_longitude`) VALUES
(1, 'Domino\'s', 'dominos.jpg', 'Shop no 45 & 46, Ground Floor, Avadh Viceroy,Beside D-Mart, Sarthana Jakat Naka, Subhash Nagar, Nana Varachha, Surat, Gujarat 395006', 'Surat', 'dominospizza@gmail.com', 9865321245, 1, 4.3, '21.2314 N', '72.9036 E'),
(2, 'McDonald\'s', 'mcd.jpg', 'Ground Valentine Cinema Vision, Surat - Dumas Rd, Magdalla, Gujarat - 395007', 'Surat', 'mcdonaldssurat@gmail.com', 8928304074, 1, 4.2, '21.1554 N', '72.7643 E'),
(3, 'Wok On Fire', 'wof.jpg', 'Shop No 2, Golden Square Building, Next to Sargam Shopping Center, Parle Point, Gujarat - 395007 ', 'Surat', 'wokonfirechinese@yahoo.com', 7203066666, 1, 3.9, '21.1720 N', '72.7901 E'),
(4, 'Kailash Sweets & Snacks', 'kailash.png', 'Ground Floor Shreenathji Apartment Timiliyawad Road, Near, Athwa Gate Cir, Timaliawad, Nanpura, Surat, Gujarat 395001', 'Surat', 'kailashsweetsnsnacks@gmail.com', 2612463688, 1, 4.1, '21.1870 N', '72.8140 E');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Application_Offer`
--
ALTER TABLE `Application_Offer`
  ADD PRIMARY KEY (`Offer_id`);

--
-- Indexes for table `Category`
--
ALTER TABLE `Category`
  ADD PRIMARY KEY (`Category_id`);

--
-- Indexes for table `Customer_Details`
--
ALTER TABLE `Customer_Details`
  ADD PRIMARY KEY (`Cust_id`),
  ADD UNIQUE KEY `phno` (`Cust_phno`),
  ADD UNIQUE KEY `email` (`Cust_email`);

--
-- Indexes for table `DE_Details`
--
ALTER TABLE `DE_Details`
  ADD PRIMARY KEY (`DE_id`),
  ADD UNIQUE KEY `DE_name` (`DE_name`),
  ADD UNIQUE KEY `DE_email` (`DE_email`);

--
-- Indexes for table `Item_Details`
--
ALTER TABLE `Item_Details`
  ADD PRIMARY KEY (`Item_id`),
  ADD KEY `Category_id` (`Category_id`),
  ADD KEY `Res_id` (`Res_id`);

--
-- Indexes for table `Offer_Restaurant`
--
ALTER TABLE `Offer_Restaurant`
  ADD PRIMARY KEY (`Offer_id`),
  ADD KEY `Res_id` (`Res_id`);

--
-- Indexes for table `Order_Details`
--
ALTER TABLE `Order_Details`
  ADD PRIMARY KEY (`Order_id`),
  ADD KEY `Res_id` (`Res_id`),
  ADD KEY `order_details_ibfk_1` (`DE_id`),
  ADD KEY `Cust_id` (`Cust_id`);

--
-- Indexes for table `Payment_Details`
--
ALTER TABLE `Payment_Details`
  ADD PRIMARY KEY (`Payment_id`),
  ADD KEY `Order_id` (`Order_id`);

--
-- Indexes for table `Restaurant_Details`
--
ALTER TABLE `Restaurant_Details`
  ADD PRIMARY KEY (`Res_id`),
  ADD UNIQUE KEY `Res_Email` (`Res_Email`),
  ADD UNIQUE KEY `Res_phno` (`Res_phno`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Application_Offer`
--
ALTER TABLE `Application_Offer`
  MODIFY `Offer_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `Category`
--
ALTER TABLE `Category`
  MODIFY `Category_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `Customer_Details`
--
ALTER TABLE `Customer_Details`
  MODIFY `Cust_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `DE_Details`
--
ALTER TABLE `DE_Details`
  MODIFY `DE_id` int(5) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `Item_Details`
--
ALTER TABLE `Item_Details`
  MODIFY `Item_id` bigint(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `Offer_Restaurant`
--
ALTER TABLE `Offer_Restaurant`
  MODIFY `Offer_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `Order_Details`
--
ALTER TABLE `Order_Details`
  MODIFY `Order_id` bigint(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `Payment_Details`
--
ALTER TABLE `Payment_Details`
  MODIFY `Payment_id` bigint(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `Restaurant_Details`
--
ALTER TABLE `Restaurant_Details`
  MODIFY `Res_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `Item_Details`
--
ALTER TABLE `Item_Details`
  ADD CONSTRAINT `item_details_ibfk_1` FOREIGN KEY (`Res_id`) REFERENCES `Restaurant_Details` (`Res_id`);

--
-- Constraints for table `Offer_Restaurant`
--
ALTER TABLE `Offer_Restaurant`
  ADD CONSTRAINT `offer_restaurant_ibfk_1` FOREIGN KEY (`Res_id`) REFERENCES `Restaurant_Details` (`Res_id`);

--
-- Constraints for table `Payment_Details`
--
ALTER TABLE `Payment_Details`
  ADD CONSTRAINT `payment_details_ibfk_1` FOREIGN KEY (`Order_id`) REFERENCES `Order_Details` (`Order_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
